/*
 * slam_gmapping
 * Copyright (c) 2008, Willow Garage, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *   * Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *   * Neither the names of Stanford University or Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived from
 *     this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* Author: Brian Gerkey */
/* Modified by: Charles DuHadway */


/**

@mainpage slam_gmapping

@htmlinclude manifest.html

@b slam_gmapping is a wrapper around the GMapping SLAM library. It reads laser
scans and odometry and computes a map. This map can be
written to a file using e.g.

  "rosrun map_server map_saver static_map:=dynamic_map"

<hr>

@section topic ROS topics

Subscribes to (name/type):
- @b "scan"/<a href="../../sensor_msgs/html/classstd__msgs_1_1LaserScan.html">sensor_msgs/LaserScan</a> : data from a laser range scanner 
- @b "/tf": odometry from the robot


Publishes to (name/type):
- @b "/tf"/tf/tfMessage: position relative to the map


@section services
 - @b "~dynamic_map" : returns the map


@section parameters ROS parameters

Reads the following parameters from the parameter server

Parameters used by our GMapping wrapper:

- @b "~throttle_scans": @b [int] throw away every nth laser scan
- @b "~base_frame": @b [string] the tf frame_id to use for the robot base pose
- @b "~map_frame": @b [string] the tf frame_id where the robot pose on the map is published
- @b "~odom_frame": @b [string] the tf frame_id from which odometry is read
- @b "~map_update_interval": @b [double] time in seconds between two recalculations of the map


Parameters used by GMapping itself:

Laser Parameters:
- @b "~/maxRange" @b [double] maximum range of the laser scans. Rays beyond this range get discarded completely. (default: maximum laser range minus 1 cm, as received in the the first LaserScan message)
- @b "~/maxUrange" @b [double] maximum range of the laser scanner that is used for map building (default: same as maxRange)
- @b "~/sigma" @b [double] standard deviation for the scan matching process (cell)
- @b "~/kernelSize" @b [int] search window for the scan matching process
- @b "~/lstep" @b [double] initial search step for scan matching (linear)
- @b "~/astep" @b [double] initial search step for scan matching (angular)
- @b "~/iterations" @b [int] number of refinement steps in the scan matching. The final "precision" for the match is lstep*2^(-iterations) or astep*2^(-iterations), respectively.
- @b "~/lsigma" @b [double] standard deviation for the scan matching process (single laser beam)
- @b "~/ogain" @b [double] gain for smoothing the likelihood
- @b "~/lskip" @b [int] take only every (n+1)th laser ray for computing a match (0 = take all rays)
- @b "~/minimumScore" @b [double] minimum score for considering the outcome of the scanmatching good. Can avoid 'jumping' pose estimates in large open spaces when using laser scanners with limited range (e.g. 5m). (0 = default. Scores go up to 600+, try 50 for example when experiencing 'jumping' estimate issues)

Motion Model Parameters (all standard deviations of a gaussian noise model)
- @b "~/srr" @b [double] linear noise component (x and y)
- @b "~/stt" @b [double] angular noise component (theta)
- @b "~/srt" @b [double] linear -> angular noise component
- @b "~/str" @b [double] angular -> linear noise component

Others:
- @b "~/linearUpdate" @b [double] the robot only processes new measurements if the robot has moved at least this many meters
- @b "~/angularUpdate" @b [double] the robot only processes new measurements if the robot has turned at least this many rads

- @b "~/resampleThreshold" @b [double] threshold at which the particles get resampled. Higher means more frequent resampling.
- @b "~/particles" @b [int] (fixed) number of particles. Each particle represents a possible trajectory that the robot has traveled

Likelihood sampling (used in scan matching)
- @b "~/llsamplerange" @b [double] linear range
- @b "~/lasamplerange" @b [double] linear step size
- @b "~/llsamplestep" @b [double] linear range
- @b "~/lasamplestep" @b [double] angular step size

Initial map dimensions and resolution:
- @b "~/xmin" @b [double] minimum x position in the map [m]
- @b "~/ymin" @b [double] minimum y position in the map [m]
- @b "~/xmax" @b [double] maximum x position in the map [m]
- @b "~/ymax" @b [double] maximum y position in the map [m]
- @b "~/delta" @b [double] size of one pixel [m]

*/



#include "slam_gmapping.h"

#include <iostream>

#include <time.h>

#include "ros/ros.h"
#include "ros/console.h"
#include "nav_msgs/MapMetaData.h"

#include "gmapping/sensor/sensor_range/rangesensor.h"
#include "gmapping/sensor/sensor_odometry/odometrysensor.h"

#include <rosbag/bag.h>
#include <rosbag/view.h>
#include <boost/foreach.hpp>
#define foreach BOOST_FOREACH

// compute linear index for given map coords
#define MAP_IDX(sx, i, j) ((sx) * (j) + (i))

SlamGMapping::SlamGMapping():
  map_to_odom_(tf::Transform(tf::createQuaternionFromRPY( 0, 0, 0 ), tf::Point(0, 0, 0 ))),
  laser_count_(0), private_nh_("~"), scan_filter_sub_(NULL), scan_filter_(NULL), transform_thread_(NULL)
{
  seed_ = time(NULL);
  init();
}

SlamGMapping::SlamGMapping(ros::NodeHandle& nh, ros::NodeHandle& pnh):
  map_to_odom_(tf::Transform(tf::createQuaternionFromRPY( 0, 0, 0 ), tf::Point(0, 0, 0 ))),
  laser_count_(0),node_(nh), private_nh_(pnh), scan_filter_sub_(NULL), scan_filter_(NULL), transform_thread_(NULL)
{
  seed_ = time(NULL);
  init();
}

SlamGMapping::SlamGMapping(long unsigned int seed, long unsigned int max_duration_buffer):
  map_to_odom_(tf::Transform(tf::createQuaternionFromRPY( 0, 0, 0 ), tf::Point(0, 0, 0 ))),
  laser_count_(0), private_nh_("~"), scan_filter_sub_(NULL), scan_filter_(NULL), transform_thread_(NULL),
  seed_(seed), tf_(ros::Duration(max_duration_buffer))
{
  init();
}


void SlamGMapping::init()
{
  // log4cxx::Logger::getLogger(ROSCONSOLE_DEFAULT_NAME)->setLevel(ros::console::g_level_lookup[ros::console::levels::Debug]);

  // The library is pretty chatty
  //gsp_ = new GMapping::GridSlamProcessor(std::cerr);
  gsp_ = new GMapping::GridSlamProcessor();
  ROS_ASSERT(gsp_);

  tfB_ = new tf::TransformBroadcaster();
  ROS_ASSERT(tfB_);

  gsp_laser_ = NULL;
  gsp_odom_ = NULL;

  got_first_scan_ = false;
  got_map_ = false;
  

  
  // Parameters used by our GMapping wrapper
  if(!private_nh_.getParam("throttle_scans", throttle_scans_))
    throttle_scans_ = 1;
  if(!private_nh_.getParam("base_frame", base_frame_))
    base_frame_ = "base_link";
  if(!private_nh_.getParam("map_frame", map_frame_))
    map_frame_ = "map";
  if(!private_nh_.getParam("odom_frame", odom_frame_))
    odom_frame_ = "odom";

  private_nh_.param("transform_publish_period", transform_publish_period_, 0.05);

  double tmp;
  if(!private_nh_.getParam("map_update_interval", tmp))
    tmp = 5.0;
  map_update_interval_.fromSec(tmp);
  
  // Parameters used by GMapping itself
  maxUrange_ = 0.0;  maxRange_ = 0.0; // preliminary default, will be set in initMapper()
  if(!private_nh_.getParam("minimumScore", minimum_score_))
    minimum_score_ = 0;
  if(!private_nh_.getParam("sigma", sigma_))
    sigma_ = 0.05;
  if(!private_nh_.getParam("kernelSize", kernelSize_))
    kernelSize_ = 1;
  if(!private_nh_.getParam("lstep", lstep_))
    lstep_ = 0.05;
  if(!private_nh_.getParam("astep", astep_))
    astep_ = 0.05;
  if(!private_nh_.getParam("iterations", iterations_))
    iterations_ = 5;
  if(!private_nh_.getParam("lsigma", lsigma_))
    lsigma_ = 0.075;
  if(!private_nh_.getParam("ogain", ogain_))
    ogain_ = 3.0;
  if(!private_nh_.getParam("lskip", lskip_))
    lskip_ = 0;
  if(!private_nh_.getParam("srr", srr_))
    srr_ = 0.1;
  if(!private_nh_.getParam("srt", srt_))
    srt_ = 0.2;
  if(!private_nh_.getParam("str", str_))
    str_ = 0.1;
  if(!private_nh_.getParam("stt", stt_))
    stt_ = 0.2;
  if(!private_nh_.getParam("linearUpdate", linearUpdate_))
    linearUpdate_ = 1.0;
  if(!private_nh_.getParam("angularUpdate", angularUpdate_))
    angularUpdate_ = 0.5;
  if(!private_nh_.getParam("temporalUpdate", temporalUpdate_))
    temporalUpdate_ = -1.0;
  if(!private_nh_.getParam("resampleThreshold", resampleThreshold_))
    resampleThreshold_ = 0.5;
  if(!private_nh_.getParam("particles", particles_))
    particles_ = 30;
  if(!private_nh_.getParam("xmin", xmin_))
    xmin_ = -100.0;
  if(!private_nh_.getParam("ymin", ymin_))
    ymin_ = -100.0;
  if(!private_nh_.getParam("xmax", xmax_))
    xmax_ = 100.0;
  if(!private_nh_.getParam("ymax", ymax_))
    ymax_ = 100.0;
  if(!private_nh_.getParam("delta", delta_))
    delta_ = 0.05;
  if(!private_nh_.getParam("occ_thresh", occ_thresh_))
    occ_thresh_ = 0.25;
  if(!private_nh_.getParam("llsamplerange", llsamplerange_))
    llsamplerange_ = 0.01;
  if(!private_nh_.getParam("llsamplestep", llsamplestep_))
    llsamplestep_ = 0.01;
  if(!private_nh_.getParam("lasamplerange", lasamplerange_))
    lasamplerange_ = 0.005;
  if(!private_nh_.getParam("lasamplestep", lasamplestep_))
    lasamplestep_ = 0.005;
    
  if(!private_nh_.getParam("tf_delay", tf_delay_))
    tf_delay_ = transform_publish_period_;

}


void SlamGMapping::startLiveSlam()
{
  entropy_publisher_ = private_nh_.advertise<std_msgs::Float64>("entropy", 1, true); //创建一个ROS发布者对象，用于发布名为"entropy"的std_msgs::Float64类型的消息，发布的消息队列长度为1，设置为true表示仅保留最新的消息

  pose_pub = node_.advertise<geometry_msgs::PoseStamped>("gmap_pose_topic", 10);
  mpose_pub  = node_.advertise<geometry_msgs::PoseStamped>("mpose_topic", 10);
  sst_ = node_.advertise<nav_msgs::OccupancyGrid>("map", 1, true);//创建一个ROS发布者对象，用于发布名为"map"的nav_msgs::OccupancyGrid类型的消息，发布的消息队列长度为1，设置为true表示仅保留最新的消息
  sstm_ = node_.advertise<nav_msgs::MapMetaData>("map_metadata", 1, true);//创建一个ROS发布者对象，用于发布名为"map_metadata"的nav_msgs::MapMetaData类型的消息，发布的消息队列长度为1，设置为true表示仅保留最新的消息。
  ss_ = node_.advertiseService("dynamic_map", &SlamGMapping::mapCallback, this);//创建一个ROS服务对象，用于提供名为"dynamic_map"的服务，回调函数为mapCallback，this指针用于指向当前的SlamGMapping对象
  scan_filter_sub_ = new message_filters::Subscriber<sensor_msgs::LaserScan>(node_, "scan", 5);//创建一个消息过滤器的订阅者对象，用于订阅名为"scan"的sensor_msgs::LaserScan类型的消息，消息队列长度为5
  scan_filter_ = new tf::MessageFilter<sensor_msgs::LaserScan>(*scan_filter_sub_, tf_, odom_frame_, 5);//创建一个基于时间的消息过滤器对象，用于对接收到的激光扫描消息进行时间同步
  scan_filter_->registerCallback(boost::bind(&SlamGMapping::laserCallback, this, _1));//将laserCallback方法绑定到消息过滤器的回调函数，即当接收到激光扫描消息时，调用laserCallback方法进行处理

  transform_thread_ = new boost::thread(boost::bind(&SlamGMapping::publishLoop, this, transform_publish_period_));//创建一个新的线程，该线程会调用publishLoop方法进行周期性地发布变换信息
}

void SlamGMapping::startReplay(const std::string & bag_fname, std::string scan_topic)
{
  double transform_publish_period;
  ros::NodeHandle private_nh_("~");//创建一个私有的ROS节点句柄，用于获取私有参数
  entropy_publisher_ = private_nh_.advertise<std_msgs::Float64>("entropy", 1, true);//创建一个ROS发布者对象，用于发布名为"entropy"的std_msgs::Float64类型的消息，发布的消息队列长度为1，设置为true表示仅保留最新的消息

  pose_pub = node_.advertise<geometry_msgs::PoseStamped>("gmap_pose_topic", 10);
  mpose_pub  = node_.advertise<geometry_msgs::PoseStamped>("mpose_topic", 10);
  sst_ = node_.advertise<nav_msgs::OccupancyGrid>("map", 1, true);//：创建一个ROS发布者对象，用于发布名为"map"的nav_msgs::OccupancyGrid类型的消息，发布的消息队列长度为1，设置为true表示仅保留最新的消息
  sstm_ = node_.advertise<nav_msgs::MapMetaData>("map_metadata", 1, true);//创建一个ROS发布者对象，用于发布名为"map_metadata"的nav_msgs::MapMetaData类型的消息，发布的消息队列长度为1，设置为true表示仅保留最新的消息
  ss_ = node_.advertiseService("dynamic_map", &SlamGMapping::mapCallback, this);//创建一个ROS服务对象，用于提供名为"dynamic_map"的服务，回调函数为mapCallback，this指针用于指向当前的SlamGMapping对象
  
  rosbag::Bag bag;//创建一个rosbag::Bag对象，用于读取ROS bag文件
  bag.open(bag_fname, rosbag::bagmode::Read);//打开指定的ROS bag文件
  
  std::vector<std::string> topics;//创建一个包含"/tf"和指定scan_topic的rosbag::TopicQuery对象，用于过滤需要处理的消息
  topics.push_back(std::string("/tf"));
  topics.push_back(scan_topic);
  rosbag::View viewall(bag, rosbag::TopicQuery(topics));

  // Store up to 5 messages and there error message (if they cannot be processed right away)
  std::queue<std::pair<sensor_msgs::LaserScan::ConstPtr, std::string> > s_queue; //定义了一个队列s_queue，用于存储LaserScan消息和相应的错误消息
  foreach(rosbag::MessageInstance const m, viewall) //使用foreach循环遍历viewall中的每个消息实例
  {
    tf::tfMessage::ConstPtr cur_tf = m.instantiate<tf::tfMessage>(); //对于每个消息实例，首先尝试将其转换为tf::tfMessage类型的指针cur_tf。如果转换成功（即cur_tf不为NULL），则进入内部循环
    if (cur_tf != NULL) {
      for (size_t i = 0; i < cur_tf->transforms.size(); ++i)
      {
        geometry_msgs::TransformStamped transformStamped;
        tf::StampedTransform stampedTf;
        transformStamped = cur_tf->transforms[i];
        tf::transformStampedMsgToTF(transformStamped, stampedTf);
        tf_.setTransform(stampedTf);
      }
    }
//在内部循环中，遍历cur_tf中的每个变换（transform），将其转换为geometry_msgs::TransformStamped类型的变量transformStamped，并将其转换为tf::StampedTransform类型的变量stampedTf。最后，使用tf_.setTransform方法设置变换。
    sensor_msgs::LaserScan::ConstPtr s = m.instantiate<sensor_msgs::LaserScan>();
    if (s != NULL) {
      if (!(ros::Time(s->header.stamp)).is_zero())
      {
        s_queue.push(std::make_pair(s, ""));
      }
      // Just like in live processing, only process the latest 5 scans   如果s_queue队列的大小超过5个，表示队列中存储的扫描数据已达到上限。此时，会弹出队列中最旧的扫描数据，并记录警告日志
      if (s_queue.size() > 5) {
        ROS_WARN_STREAM("Dropping old scan: " << s_queue.front().second);
        s_queue.pop();
      }
      // ignoring un-timestamped tf data 
    }

    // Only process a scan if it has tf data
    while (!s_queue.empty()) //在一个循环中处理存储在s_queue队列中的扫描数据
    {
      try
      {
        tf::StampedTransform t; //获取到的变换将存储在tf::StampedTransform类型的变量t中
        tf_.lookupTransform(s_queue.front().first->header.frame_id, odom_frame_, s_queue.front().first->header.stamp, t);//通过调用tf_.lookupTransform方法获取扫描数据的坐标变换。该方法根据扫描数据的帧ID（s_queue.front().first->header.frame_id）和时间戳（s_queue.front().first->header.stamp）来查找并返回相应的变换
        this->laserCallback(s_queue.front().first);//调用laserCallback方法，将扫描数据作为参数传递给该方法进行处理
        s_queue.pop();//从s_queue队列中移除已处理的扫描数据
      }
      // If tf does not have the data yet
      catch(tf2::TransformException& e)//如果在查找坐标变换时发生了异常（tf2::TransformException），通常是因为坐标变换数据尚未准备好或无法获取到，将捕获该异常并进行处理
      {
        // Store the error to display it if we cannot process the data after some time
        s_queue.front().second = std::string(e.what());//在异常处理块中，将异常信息存储在s_queue.front().second中，以便在无法在一定时间内处理数据时显示错误信息
        break;
      }
    }
  }

  bag.close(); //关闭打开的rosbag文件
}

void SlamGMapping::publishLoop(double transform_publish_period){ //在一定的时间间隔内发布坐标变换信息
  if(transform_publish_period == 0) //首先，函数检查transform_publish_period是否为0，如果是则直接返回，不进行后续操作
    return;

  ros::Rate r(1.0 / transform_publish_period);//创建一个ros::Rate对象，指定了发布频率，计算方式是根据transform_publish_period计算出每秒发布的频率
  while(ros::ok()){
    publishTransform();//在一个循环中，通过调用publishTransform方法发布坐标变换信息
    r.sleep();//使用r.sleep()方法暂停一段时间，以满足设定的发布频率
  }
}

SlamGMapping::~SlamGMapping()//析构函数,用于清理SlamGMapping类的实例对象在销毁时所分配的资源
{
  if(transform_thread_){
    transform_thread_->join();
    delete transform_thread_;
  }

  delete gsp_;
  if(gsp_laser_)
    delete gsp_laser_;
  if(gsp_odom_)
    delete gsp_odom_;
  if (scan_filter_)
    delete scan_filter_;
  if (scan_filter_sub_)
    delete scan_filter_sub_;
}

bool
SlamGMapping::getOdomPose(GMapping::OrientedPoint& gmap_pose, const ros::Time& t)  //获取当前时刻的里程计姿态信息.通过转换激光坐标系到里程计坐标系获取指定时刻的里程计姿态信息
{
  // Get the pose of the centered laser at the right time
  centered_laser_pose_.stamp_ = t;//将centered_laser_pose_的时间戳设置为指定的时刻t
  // Get the laser's pose that is centered
  tf::Stamped<tf::Transform> odom_pose;//定义一个Stamped类型的变量odom_pose，用于存储获取到的里程计姿态
  try//尝试获取里程计姿态信息
  {
    tf_.transformPose(odom_frame_, centered_laser_pose_, odom_pose);//使用tf_对象的transformPose方法将centered_laser_pose_从激光坐标系转换到里程计坐标系，并将结果存储在odom_pose中
  }
  catch(tf::TransformException e)//如果转换过程中出现异常，则进入catch块
  {
    ROS_WARN("Failed to compute odom pose, skipping scan (%s)", e.what());//输出警告信息，提示获取里程计姿态失败，并附带错误信息
    return false;//返回false，表示获取姿态失败
  }
  double yaw = tf::getYaw(odom_pose.getRotation());   //获取旋转角度

  gmap_pose = GMapping::OrientedPoint(odom_pose.getOrigin().x(),  //获取x轴位置坐标
                                      odom_pose.getOrigin().y(),  //获取y轴位置坐标
                                      yaw);
  return true;//返回true，表示成功获取了姿态信息
}

bool
SlamGMapping::initMapper(const sensor_msgs::LaserScan& scan) //初始化地图构建过程.输入参数是一个sensor_msgs::LaserScan类型的激光扫描数据scan
{
  laser_frame_ = scan.header.frame_id; //将激光扫描数据的帧ID赋值给laser_frame_变量，表示激光数据所在的坐标系
  // Get the laser's pose, relative to base.
  tf::Stamped<tf::Pose> ident;//定义了两个Stamped类型的变量ident和laser_pose，用于存储激光的姿态信息.
  tf::Stamped<tf::Transform> laser_pose;//laser_pose用于存储转换后的激光姿态信息
  ident.setIdentity();//ident初始化为单位姿态
  ident.frame_id_ = laser_frame_;//将ident的帧ID设置为激光数据的帧ID，表示激光数据相对于自身的姿态
  ident.stamp_ = scan.header.stamp;//将ident的时间戳设置为激光数据的时间戳，保持与激光数据相同的时间
  try//尝试将激光姿态从激光坐标系转换到基准坐标系（例如机器人底盘坐标系）
  {
    tf_.transformPose(base_frame_, ident, laser_pose);//使用tf_对象的transformPose方法将ident从激光坐标系转换到基准坐标系，并将结果存储在laser_pose中
  }
  catch(tf::TransformException e)//如果转换过程中出现异常，则进入catch块
  {
    ROS_WARN("Failed to compute laser pose, aborting initialization (%s)",//输出警告信息，提示无法计算激光姿态，并附带错误信息
             e.what());
    return false;//返回false，表示初始化失败
  }

  // create a point 1m above the laser position and transform it into the laser-frame
  tf::Vector3 v;//创建一个tf::Vector3类型的向量v，并设置其x、y、z分量的值
  v.setValue(0, 0, 1 + laser_pose.getOrigin().z());//将向量的z分量设置为1加上激光姿态在基准坐标系下的z坐标
  tf::Stamped<tf::Vector3> up(v, scan.header.stamp,//创建一个tf::Stamped<tf::Vector3>类型的向量up，并将其与激光扫描数据的时间戳和基准坐标系关联起来
                                      base_frame_);
  try//尝试将向量up从基准坐标系转换到激光坐标系
  {
    tf_.transformPoint(laser_frame_, up, up);//使用tf_对象的transformPoint方法将up从基准坐标系转换到激光坐标系，并将结果存储在up中
    ROS_DEBUG("Z-Axis in sensor frame: %.3f", up.z());
  }
  catch(tf::TransformException& e)//如果转换过程中出现异常，则进入catch块
  {
    ROS_WARN("Unable to determine orientation of laser: %s", //如果转换失败，则输出警告信息，提示无法确定激光的方向，并返回false表示初始化失败
             e.what());
    return false;
  }

  // gmapping doesnt take roll or pitch into account. So check for correct sensor alignment. 检查激光的方向向量是否与z轴对齐（垂直朝上或垂直朝下）
  if (fabs(fabs(up.z()) - 1) > 0.001) //判断z分量的绝对值与1的差的绝对值是否大于0.001，如果大于则说明激光方向向量与z轴不对齐
  {
    ROS_WARN("Laser has to be mounted planar! Z-coordinate has to be 1 or -1, but gave: %.5f",
                 up.z()); //如果不对齐，则输出警告信息，提示激光必须安装在平面上，并返回false表示初始化失败
    return false;
  }

  gsp_laser_beam_count_ = scan.ranges.size(); //记录激光束的数量，即激光扫描数据中的测量点数量

  double angle_center = (scan.angle_min + scan.angle_max)/2; //计算激光的中心角度，即激光扫描数据中角度的平均值

  if (up.z() > 0)//根据激光方向向量的z分量的正负值，确定激光的安装方向（朝上或朝下）.如果z分量大于0，表示激光朝上安装
  {
    do_reverse_range_ = scan.angle_min > scan.angle_max;//设置do_reverse_range_标志，用于指示激光角度是否需要反向
    centered_laser_pose_ = tf::Stamped<tf::Pose>(tf::Transform(tf::createQuaternionFromRPY(0,0,angle_center),//创建一个相对于激光坐标系中心对称的姿态，并将其存储在centered_laser_pose_中
                                                               tf::Vector3(0,0,0)), ros::Time::now(), laser_frame_);
    ROS_INFO("Laser is mounted upwards.");//输出信息表示激光朝上安装
  }
  else//如果z分量小于等于0，表示激光朝下安装
  {
    do_reverse_range_ = scan.angle_min < scan.angle_max;//设置do_reverse_range_标志，用于指示激光角度是否需要反向
    centered_laser_pose_ = tf::Stamped<tf::Pose>(tf::Transform(tf::createQuaternionFromRPY(M_PI,0,-angle_center),//创建一个相对于激光坐标系中心对称的姿态，并将其存储在centered_laser_pose_中
                                                               tf::Vector3(0,0,0)), ros::Time::now(), laser_frame_);
    ROS_INFO("Laser is mounted upside down.");//输出信息表示激光朝下安装
  }

  // Compute the angles of the laser from -x to x, basically symmetric and in increasing order  计算激光束的角度范围，从 -x 到 x，基本上是对称的且递增顺序
  laser_angles_.resize(scan.ranges.size());//根据激光扫描数据中的测量点数量，调整laser_angles_向量的大小
  // Make sure angles are started so that they are centered
  double theta = - std::fabs(scan.angle_min - scan.angle_max)/2;//
  for(unsigned int i=0; i<scan.ranges.size(); ++i)//通过循环为每个测量点计算角度，并将其存储在laser_angles_中
  {
    laser_angles_[i]=theta;
    theta += std::fabs(scan.angle_increment);
  }
  //输出调试信息，显示激光在激光坐标系和中心对称激光坐标系中的角度范围
  ROS_DEBUG("Laser angles in laser-frame: min: %.3f max: %.3f inc: %.3f", scan.angle_min, scan.angle_max,
            scan.angle_increment);
  ROS_DEBUG("Laser angles in top-down centered laser-frame: min: %.3f max: %.3f inc: %.3f", laser_angles_.front(),
            laser_angles_.back(), std::fabs(scan.angle_increment));

  GMapping::OrientedPoint gmap_pose(0, 0, 0);//创建一个名为gmap_pose的GMapping::OrientedPoint对象，并将其初始化为(0, 0, 0)

  // setting maxRange and maxUrange here so we can set a reasonable default
  ros::NodeHandle private_nh_("~");
  if(!private_nh_.getParam("maxRange", maxRange_))//从私有命名空间获取maxRange参数的值，如果未指定，则将其设置为激光扫描数据的range_max减去0.01。
    maxRange_ = scan.range_max - 0.01;
  if(!private_nh_.getParam("maxUrange", maxUrange_))//从私有命名空间获取maxUrange参数的值，如果未指定，则将其设置为maxRange_的值。
    maxUrange_ = maxRange_;

  // The laser must be called "FLASER".
  // We pass in the absolute value of the computed angle increment, on the
  // assumption that GMapping requires a positive angle increment.  If the
  // actual increment is negative, we'll swap the order of ranges before
  // feeding each scan to GMapping.
  gsp_laser_ = new GMapping::RangeSensor("FLASER",     //创建一个GMapping::RangeSensor对象gsp_laser_，表示激光传感器.   使用名称"FLASER"创建激光传感器
                                         gsp_laser_beam_count_,//设置激光束数量为gsp_laser_beam_count_
                                         fabs(scan.angle_increment),//激光束的角度增量
                                         gmap_pose,//使用先前计算得到的初始姿态gmap_pose创建激光传感器
                                         0.0,//设置激光传感器的最小测量范围为0.0
                                         maxRange_);//设置激光传感器的最大测量范围为maxRange_
  ROS_ASSERT(gsp_laser_);//使用ROS_ASSERT断言确保激光传感器对象成功创建

  GMapping::SensorMap smap;//创建一个GMapping::SensorMap对象smap，用于存储传感器对象的映射关系
  smap.insert(make_pair(gsp_laser_->getName(), gsp_laser_));//将激光传感器对象添加到smap中，使用激光传感器对象的名称作为键
  gsp_->setSensorMap(smap);//将smap设置为gsp_（GMapping::GridSlamProcessor对象）的传感器映射.这将告诉gsp_使用刚刚创建的激光传感器进行SLAM

  gsp_odom_ = new GMapping::OdometrySensor(odom_frame_);//创建一个GMapping::OdometrySensor对象gsp_odom_，表示里程计传感器.使用odom_frame_作为里程计传感器的参考坐标系
  ROS_ASSERT(gsp_odom_);//使用ROS_ASSERT断言确保里程计传感器对象成功创建


  /// @todo Expose setting an initial pose
  GMapping::OrientedPoint initialPose;  //获取激光扫描数据的初始姿态initialPose
  if(!getOdomPose(initialPose, scan.header.stamp)) //调用getOdomPose函数来获取里程计坐标系中的激光姿态
  {
    ROS_WARN("Unable to determine inital pose of laser! Starting point will be set to zero.");//输出警告信息表示无法确定激光的初始姿态，将其设置为零点
    initialPose = GMapping::OrientedPoint(0.0, 0.0, 0.0);//如果无法获取姿态信息，则将初始姿态设置为(0.0, 0.0, 0.0)
  }

  gsp_->setMatchingParameters(maxUrange_, maxRange_, sigma_,//设置gsp_的匹配参数、运动模型参数、更新距离、更新周期、粒子数量等等。
                              kernelSize_, lstep_, astep_, iterations_,
                              lsigma_, ogain_, lskip_);

  gsp_->setMotionModelParameters(srr_, srt_, str_, stt_);//使用初始姿态和地图边界信息初始化gsp_（GridSlamProcessor对象）
  gsp_->setUpdateDistances(linearUpdate_, angularUpdate_, resampleThreshold_);
  gsp_->setUpdatePeriod(temporalUpdate_);
  gsp_->setgenerateMap(false);
  gsp_->GridSlamProcessor::init(particles_, xmin_, ymin_, xmax_, ymax_,
                                delta_, initialPose);
  gsp_->setllsamplerange(llsamplerange_); //设置低分辨率采样参数和高分辨率采样参数
  gsp_->setllsamplestep(llsamplestep_);
  /// @todo Check these calls; in the gmapping gui, they use
  /// llsamplestep and llsamplerange intead of lasamplestep and
  /// lasamplerange.  It was probably a typo, but who knows.
  gsp_->setlasamplerange(lasamplerange_);
  gsp_->setlasamplestep(lasamplestep_);
  gsp_->setminimumScore(minimum_score_);

  // Call the sampling function once to set the seed.
  GMapping::sampleGaussian(1,seed_);//调用sampleGaussian函数生成一个高斯分布样本，用于设置随机数种子

  ROS_INFO("Initialization complete");//输出信息表示初始化完成

  return true;//返回true，表示初始化成功
}

bool
SlamGMapping::addScan(const sensor_msgs::LaserScan& scan, GMapping::OrientedPoint& gmap_pose) //向SLAM算法添加激光扫描数据的功能
{
  if(!getOdomPose(gmap_pose, scan.header.stamp))//调用getOdomPose函数获取激光扫描数据的里程计姿态gmap_pose.如果无法获取姿态信息，则返回false
     return false;
  
  if(scan.ranges.size() != gsp_laser_beam_count_)//检查激光扫描数据的激光束数量是否与初始化时设置的激光束数量一致。如果不一致，则返回false。
    return false;

  // GMapping wants an array of doubles...
  double* ranges_double = new double[scan.ranges.size()]; //创建一个double类型的动态数组ranges_double，用于存储激光测量值。数组的大小为激光扫描数据中激光束的数量。然后根据激光束的顺序，将激光测量值填充到ranges_double数组中
  // If the angle increment is negative, we have to invert the order of the readings.
  if (do_reverse_range_)//如果需要反转激光测量值的顺序，则遍历过程中将激光测量值倒序填充到数组中
  {
    ROS_DEBUG("Inverting scan");
    int num_ranges = scan.ranges.size();
    for(int i=0; i < num_ranges; i++)
    {
      // Must filter out short readings, because the mapper won't
      if(scan.ranges[num_ranges - i - 1] < scan.range_min) //对于小于scan.range_min的激光测量值，将其替换为scan.range_max
        ranges_double[i] = (double)scan.range_max;
      else
        ranges_double[i] = (double)scan.ranges[num_ranges - i - 1];
    }
  } else 
  {
    for(unsigned int i=0; i < scan.ranges.size(); i++)
    {
      // Must filter out short readings, because the mapper won't
      if(scan.ranges[i] < scan.range_min)
        ranges_double[i] = (double)scan.range_max;
      else
        ranges_double[i] = (double)scan.ranges[i];
    }
  }

  GMapping::RangeReading reading(scan.ranges.size(),//创建一个GMapping::RangeReading对象reading，表示一次激光扫描的测量数据
                                 ranges_double,//使用ranges_double数组、激光传感器对象gsp_laser_和激光扫描数据的时间戳创建RangeReading对象。
                                 gsp_laser_,
                                 scan.header.stamp.toSec());

  // ...but it deep copies them in RangeReading constructor, so we don't
  // need to keep our array around.
  delete[] ranges_double;

  reading.setPose(gmap_pose);//设置reading的姿态为gmap_pose

  ROS_DEBUG("scanpose (%.3f): %.3f %.3f %.3f\n",//使用 ROS_DEBUG 输出调试信息，打印激光扫描的时间戳以及 gmap_pose 的 x、y、theta 坐标
            scan.header.stamp.toSec(),
            gmap_pose.x,
            gmap_pose.y,
            gmap_pose.theta);

  ROS_DEBUG("processing scan");//使用 ROS_DEBUG 输出调试信息，表示正在处理激光扫描


  //ros::Publisher pose_pub = nh.advertise<geometry_msgs::PoseStamped>("gmap_pose_topic", 10);

    // 在适当的时候发布gmap_pose
  GMapping::OrientedPoint gmap_pose1(0, 0, 0);

  geometry_msgs::PoseStamped pose_msg;
  pose_msg.pose.position.x = gmap_pose1.x;
  pose_msg.pose.position.y = gmap_pose1.y;
  pose_msg.pose.orientation.z = gmap_pose1.theta;

    // 设置时间戳等其他信息
  pose_msg.header.stamp = ros::Time::now();
  pose_msg.header.frame_id = "map";  // 设置坐标系

  pose_pub.publish(pose_msg);

  return gsp_->processScan(reading);//调用gsp_->processScan函数将激光扫描数据传递给SLAM算法进行处理.返回processScan函数的执行结果，表示是否成功处理激光扫描数据
}

void
SlamGMapping::laserCallback(const sensor_msgs::LaserScan::ConstPtr& scan)//激光数据的回调函数laserCallback，用于接收激光数据并进行处理
{
  laser_count_++;//增加激光计数laser_count_的值，表示接收到了一个激光数据
  if ((laser_count_ % throttle_scans_) != 0)//判断是否需要对接收的激光数据进行限流操作，以减少计算负载.如果laser_count_除以throttle_scans_的余数不等于0，则直接返回，不进行后续处理。
    return;

  static ros::Time last_map_update(0,0);//定义一个静态变量last_map_update，用于记录上一次更新地图的时间

  // We can't initialize the mapper until we've got the first scan
  if(!got_first_scan_)//在接收到第一帧激光数据之前，无法初始化SLAM算法的映射器（mapper）
  {
    if(!initMapper(*scan))//如果还没有接收到第一帧激光数据，则调用initMapper函数进行初始化
      return;//如果初始化失败，则直接返回，不进行后续处理。
    got_first_scan_ = true;//如果成功初始化，则将got_first_scan_标志设置为true，表示已经接收到了第一帧激光数据。
  }

  GMapping::OrientedPoint odom_pose;//声明一个GMapping::OrientedPoint类型的变量odom_pose，用于存储激光数据对应的里程计姿态

  if(addScan(*scan, odom_pose))//调用addScan函数将接收到的激光数据添加到SLAM算法中进行处理，并获取激光数据对应的里程计姿态odom_pose
  {
    ROS_DEBUG("scan processed");

    GMapping::OrientedPoint mpose = gsp_->getParticles()[gsp_->getBestParticleIndex()].pose;//输出调试信息，包括最佳粒子的姿态、里程计姿态以及姿态校正信息
    ROS_DEBUG("new best pose: %.3f %.3f %.3f", mpose.x, mpose.y, mpose.theta);
    ROS_DEBUG("odom pose: %.3f %.3f %.3f", odom_pose.x, odom_pose.y, odom_pose.theta);
    ROS_DEBUG("correction: %.3f %.3f %.3f", mpose.x - odom_pose.x, mpose.y - odom_pose.y, mpose.theta - odom_pose.theta);

    tf::Transform laser_to_map = tf::Transform(tf::createQuaternionFromRPY(0, 0, mpose.theta), tf::Vector3(mpose.x, mpose.y, 0.0)).inverse();//根据最佳粒子的姿态计算激光坐标系到地图坐标系的变换关系
    tf::Transform odom_to_laser = tf::Transform(tf::createQuaternionFromRPY(0, 0, odom_pose.theta), tf::Vector3(odom_pose.x, odom_pose.y, 0.0));//根据里程计姿态计算里程计坐标系到激光坐标系的变换关系

    map_to_odom_mutex_.lock();//加锁访问map_to_odom_，并更新地图到里程计的变换关系
    map_to_odom_ = (odom_to_laser * laser_to_map).inverse();//将odom_to_laser * laser_to_map的逆作为地图到里程计的变换关系，并存储到map_to_odom_变量中
    map_to_odom_mutex_.unlock();//解锁map_to_odom_的访问

    if(!got_map_ || (scan->header.stamp - last_map_update) > map_update_interval_)//判断是否需要更新地图.如果还没有获取地图或者距离上次地图更新的时间超过了map_update_interval_，则进行地图更新
    {
      updateMap(*scan);
      last_map_update = scan->header.stamp;
      ROS_DEBUG("Updated the map");
    }
  } else
    ROS_DEBUG("cannot process scan");

//  mpose_pub  = nh.advertise<geometry_msgs::PoseStamped>("mpose_topic", 10);
  GMapping::OrientedPoint mpose(0,0,0);
  geometry_msgs::PoseStamped mpose_msg;
  mpose_msg.pose.position.x = mpose.x;
  mpose_msg.pose.position.y = mpose.y;
  mpose_msg.pose.orientation.z = mpose.theta;

    // 设置时间戳等其他信息
  mpose_msg.header.stamp = ros::Time::now();
  mpose_msg.header.frame_id = "base_link";  // 设置应用场景中使用坐标系

  mpose_pub.publish(mpose_msg);

}

double
SlamGMapping::computePoseEntropy() //计算粒子滤波器中粒子的姿态熵（pose entropy）
{
  double weight_total=0.0; //定义了一个名为weight_total的变量，初始化为0.0，用于存储所有粒子的权重之和
  for(std::vector<GMapping::GridSlamProcessor::Particle>::const_iterator it = gsp_->getParticles().begin(); //遍历粒子滤波器中的所有粒子,累加所有粒子的权重，将每个粒子的权重（it->weight）加到weight_total中
      it != gsp_->getParticles().end();
      ++it)
  {
    weight_total += it->weight;
  }
  double entropy = 0.0;//定义了一个名为entropy的变量，初始化为0.0，用于存储计算得到的熵值
  for(std::vector<GMapping::GridSlamProcessor::Particle>::const_iterator it = gsp_->getParticles().begin();//通过一个循环遍历粒子滤波器中的所有粒子，计算每个粒子的归一化权重
      it != gsp_->getParticles().end();
      ++it)
  {
    if(it->weight/weight_total > 0.0)//如果归一化权重大于0.0，则将其乘以以自然对数为底的对数值log(it->weight/weight_total)并累加到entropy中
      entropy += it->weight/weight_total * log(it->weight/weight_total);
  }
  return -entropy;//返回-entropy，即计算得到的姿态熵的负值,常用于评估滤波器的精度和确定性.姿态熵用于表示粒子集合中姿态（例如位置和方向）的不确定性程度。熵值越高，表示不确定性越大。
}

void
SlamGMapping::updateMap(const sensor_msgs::LaserScan& scan)//更新地图
{
  ROS_DEBUG("Update map");//调试模式下输出调试信息，打印"Update map"
  boost::mutex::scoped_lock map_lock (map_mutex_);//使用互斥锁map_mutex_对地图进行加锁，以确保在更新地图时不会出现冲突
  GMapping::ScanMatcher matcher;//创建一个ScanMatcher对象matcher，用于执行扫描匹配操作

  matcher.setLaserParameters(scan.ranges.size(), &(laser_angles_[0]),
                             gsp_laser_->getPose());//设置扫描仪参数，包括扫描点数（scan.ranges.size()）、扫描角度（&(laser_angles_[0])）和扫描仪的姿态（gsp_laser_->getPose()）。

  matcher.setlaserMaxRange(maxRange_);//设置扫描仪的最大测距范围（maxRange_）和可用范围（maxUrange_）
  matcher.setusableRange(maxUrange_);
  matcher.setgenerateMap(true);//设置生成地图的标志为true，表示在扫描匹配过程中生成地图

  GMapping::GridSlamProcessor::Particle best =//获取粒子滤波器中最佳粒子的索引，并通过该索引从粒子集合中获取最佳粒子
          gsp_->getParticles()[gsp_->getBestParticleIndex()];
  std_msgs::Float64 entropy;//创建一个std_msgs::Float64类型的消息变量entropy，用于存储计算得到的姿态熵
  entropy.data = computePoseEntropy();//调用computePoseEntropy()方法计算姿态熵，并将结果存储在entropy.data中
  if(entropy.data > 0.0)//如果姿态熵大于0.0，则通过entropy_publisher_发布姿态熵消息
    entropy_publisher_.publish(entropy);

  if(!got_map_) {//判断是否已经获取到地图。如果没有获取到地图，则进行初始化设置，包括设置地图的分辨率（delta_）和原点位置
    map_.map.info.resolution = delta_;
    map_.map.info.origin.position.x = 0.0;
    map_.map.info.origin.position.y = 0.0;
    map_.map.info.origin.position.z = 0.0;
    map_.map.info.origin.orientation.x = 0.0;
    map_.map.info.origin.orientation.y = 0.0;
    map_.map.info.origin.orientation.z = 0.0;
    map_.map.info.origin.orientation.w = 1.0;
  } 

  GMapping::Point center;//创建一个GMapping::Point对象center，用于表示地图的中心点，计算并设置中心点的x和y坐标
  center.x=(xmin_ + xmax_) / 2.0;
  center.y=(ymin_ + ymax_) / 2.0;

  GMapping::ScanMatcherMap smap(center, xmin_, ymin_, xmax_, ymax_, //创建一个GMapping::ScanMatcherMap对象smap，用于存储扫描匹配的地图数据。设置地图的中心点、边界坐标和分辨率。
                                delta_);

  ROS_DEBUG("Trajectory tree:");//在调试模式下输出"Trajectory tree:"
  for(GMapping::GridSlamProcessor::TNode* n = best.node;//通过一个循环遍历最佳粒子的轨迹树。循环的目的是从最佳粒子的节点开始，沿着父节点的链表逐步向上遍历整个轨迹树。
      n;
      n = n->parent)
  {
    ROS_DEBUG("  %.3f %.3f %.3f",//在循环内部，首先在调试模式下输出当前节点的姿态信息，包括x、y和theta坐标（n->pose.x、n->pose.y、n->pose.theta）
              n->pose.x,
              n->pose.y,
              n->pose.theta);
    if(!n->reading)//检查当前节点的读数（n->reading）是否为NULL。如果为NULL，说明当前节点没有有效的读数数据，输出"Reading is NULL"并跳过本次循环
    {
      ROS_DEBUG("Reading is NULL");
      continue;
    }
    matcher.invalidateActiveArea();//调用matcher.invalidateActiveArea()方法来使活动区域无效
    matcher.computeActiveArea(smap, n->pose, &((*n->reading)[0]));//调用matcher.computeActiveArea()方法计算活动区域，将扫描匹配地图（smap）、当前节点的姿态（n->pose）以及读数数据（&((*n->reading)[0])）作为参数传入
    matcher.registerScan(smap, n->pose, &((*n->reading)[0]));//调用matcher.registerScan()方法将扫描数据注册到扫描匹配地图中，同样使用扫描匹配地图、当前节点的姿态和读数数据作为参数
  }

  // the map may have expanded, so resize ros message as well   调整地图的大小，以便与扫描匹配地图的大小保持一致
  if(map_.map.info.width != (unsigned int) smap.getMapSizeX() || map_.map.info.height != (unsigned int) smap.getMapSizeY()) {//首先，检查地图消息map_.map的宽度和高度是否与扫描匹配地图的大小不匹配。如果不匹配，则进行地图的调整。


    // NOTE: The results of ScanMatcherMap::getSize() are different from the parameters given to the constructor
    //       so we must obtain the bounding box in a different way
    GMapping::Point wmin = smap.map2world(GMapping::IntPoint(0, 0));//通过调用map2world()方法，将地图中的左上角（0, 0）和右下角（smap.getMapSizeX(), smap.getMapSizeY()）的网格坐标转换为世界坐标，得到地图的最小和最大边界坐标
    GMapping::Point wmax = smap.map2world(GMapping::IntPoint(smap.getMapSizeX(), smap.getMapSizeY()));
    xmin_ = wmin.x; ymin_ = wmin.y;//更新SlamGMapping类中的变量xmin_、ymin_、xmax_和ymax_，分别为地图的最小x、y坐标和最大x、y坐标
    xmax_ = wmax.x; ymax_ = wmax.y;
    
    ROS_DEBUG("map size is now %dx%d pixels (%f,%f)-(%f, %f)", smap.getMapSizeX(), smap.getMapSizeY(),
              xmin_, ymin_, xmax_, ymax_);//在调试模式下输出地图的大小和边界坐标信息

    map_.map.info.width = smap.getMapSizeX();//更新地图消息的宽度（map_.map.info.width）和高度（map_.map.info.height）为扫描匹配地图的大小
    map_.map.info.height = smap.getMapSizeY();
    map_.map.info.origin.position.x = xmin_;//更新地图消息的原点位置为最小边界坐标（xmin_、ymin_）
    map_.map.info.origin.position.y = ymin_;
    map_.map.data.resize(map_.map.info.width * map_.map.info.height);//调整地图数据数组的大小（map_.map.data.resize(map_.map.info.width * map_.map.info.height)），使其与新的地图尺寸匹配

    ROS_DEBUG("map origin: (%f, %f)", map_.map.info.origin.position.x, map_.map.info.origin.position.y);//在调试模式下输出地图的原点坐标
  }
//将扫描匹配地图的数据转换为地图消息数据，并发布地图消息
  for(int x=0; x < smap.getMapSizeX(); x++)//通过两个嵌套的循环遍历扫描匹配地图的每个网格
  {
    for(int y=0; y < smap.getMapSizeY(); y++)
    {
      /// @todo Sort out the unknown vs. free vs. obstacle thresholding
      GMapping::IntPoint p(x, y);//首先创建一个GMapping::IntPoint对象p，表示当前网格的坐标
      double occ=smap.cell(p);//获取当前网格的占用概率值（occ）通过调用cell()方法
      assert(occ <= 1.0);//使用断言（assert(occ <= 1.0)）确保占用概率值不超过1.0
      if(occ < 0)//根据占用概率值进行分类处理.如果占用概率值小于0，说明该网格为未知区域，将地图数据数组中对应位置（使用MAP_IDX()宏计算索引）设置为-1
        map_.map.data[MAP_IDX(map_.map.info.width, x, y)] = -1;
      else if(occ > occ_thresh_)//如果占用概率值大于occ_thresh_（阈值），说明该网格为障碍物区域，将地图数据数组中对应位置设置为100
      {
        //map_.map.data[MAP_IDX(map_.map.info.width, x, y)] = (int)round(occ*100.0);
        map_.map.data[MAP_IDX(map_.map.info.width, x, y)] = 100;
      }
      else//如果占用概率值介于0和occ_thresh_之间，说明该网格为自由区域，将地图数据数组中对应位置设置为0
        map_.map.data[MAP_IDX(map_.map.info.width, x, y)] = 0;
    }
  }
  got_map_ = true;//完成所有网格的处理后，将got_map_标志设置为true，表示已获取到地图

  //make sure to set the header information on the map
  map_.map.header.stamp = ros::Time::now();//设置地图消息的时间戳为当前时间（ros::Time::now()）和帧ID为地图坐标系的解析结果（tf_.resolve(map_frame_)）
  map_.map.header.frame_id = tf_.resolve( map_frame_ );

  sst_.publish(map_.map);//通过地图发布器sst_发布地图消息map_.map
  sstm_.publish(map_.map.info);//通过地图信息发布器sstm_发布地图消息的信息部分map_.map.info
}

bool 
SlamGMapping::mapCallback(nav_msgs::GetMap::Request  &req,//回调函数，用于处理nav_msgs::GetMap的服务请求.它接受一个请求对象req和一个响应对象res作为参数
                          nav_msgs::GetMap::Response &res)
{
  boost::mutex::scoped_lock map_lock (map_mutex_);//通过互斥锁map_mutex_对地图进行加锁，以确保在处理地图数据时不会发生冲突
  if(got_map_ && map_.map.info.width && map_.map.info.height)//通过条件判断，检查是否已经获取到地图（got_map_为true）且地图的宽度和高度非零
  {
    res = map_;//如果满足条件，将地图数据map_赋值给响应对象res，并返回true表示服务调用成功
    return true;
  }
  else//如果不满足条件，返回false表示服务调用失败
    return false;
}

void SlamGMapping::publishTransform() //发布地图到里程计的坐标变换
{
  map_to_odom_mutex_.lock();//通过互斥锁map_to_odom_mutex_对地图到里程计坐标变换进行加锁，以确保在发布坐标变换时不会发生冲突
  ros::Time tf_expiration = ros::Time::now() + ros::Duration(tf_delay_);//计算坐标变换的过期时间tf_expiration，通过当前时间加上延迟时间tf_delay_得到
  tfB_->sendTransform( tf::StampedTransform (map_to_odom_, tf_expiration, map_frame_, odom_frame_));//通过tfB_（TransformBroadcaster）对象发布地图到里程计的坐标变换，使用tf::StampedTransform表示带有时间戳的坐标变换，参数包括地图坐标系、里程计坐标系和坐标变换的过期时间
  map_to_odom_mutex_.unlock();//解锁地图到里程计坐标变换的互斥锁
}
