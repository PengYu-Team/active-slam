#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <iostream>
#include <string>
#include <vector>
#include "stdint.h"
#include "functions.h"
#include "mtrand.h"


#include "nav_msgs/OccupancyGrid.h"
#include "geometry_msgs/PointStamped.h"
#include "std_msgs/Header.h"
#include "nav_msgs/MapMetaData.h"
#include "geometry_msgs/Point.h"
#include "visualization_msgs/Marker.h"
#include <tf/transform_listener.h>



// global variables
nav_msgs::OccupancyGrid mapData;//声明了一个名为mapData的nav_msgs::OccupancyGrid类型的变量，用于存储占据栅格地图数据
geometry_msgs::PointStamped clickedpoint;//声明了一个名为clickedpoint的geometry_msgs::PointStamped类型的变量，用于存储包含时间戳的二维点数据
geometry_msgs::PointStamped exploration_goal;//声明了一个名为exploration_goal的geometry_msgs::PointStamped类型的变量，用于存储包含时间戳的探索目标点数据。
visualization_msgs::Marker points,line;//声明了两个变量，points和line，它们的类型是visualization_msgs::Marker，用于可视化目的，例如绘制点、线等。
float xdim,ydim,resolution,Xstartx,Xstarty,init_map_x,init_map_y;//声明了一些浮点型变量，用于存储地图的维度、分辨率以及起始位置等信息

rdm r; // for genrating random numbers   创建了一个名为r的rdm对象，用于生成随机数



//Subscribers callback functions---------------------------------------
void mapCallBack(const nav_msgs::OccupancyGrid::ConstPtr& msg)//当订阅者接收到新的地图消息时，会调用这个回调函数
{
mapData=*msg;//函数将接收到的地图消息内容复制给名为mapData的全局变量，以便其他部分的代码可以使用最新的地图数据
}



void rvizCallBack(const geometry_msgs::PointStamped::ConstPtr& msg)//当订阅者接收到新的RViz点击点消息时，会调用这个回调函数
{

geometry_msgs::Point p;//函数从接收到的消息中提取出点的坐标信息，并将其添加到名为points的全局变量的points数组中
p.x=msg->point.x;
p.y=msg->point.y;
p.z=msg->point.z;

points.points.push_back(p);

}




int main(int argc, char **argv)
{

  unsigned long init[4] = {0x123, 0x234, 0x345, 0x456}, length = 7;//定义了一个名为init的无符号长整型数组，并将其初始化为{0x123, 0x234, 0x345, 0x456}。同时定义了一个名为length的无符号长整型变量，并将其赋值为7
  MTRand_int32 irand(init, length); // 32-bit int generator  使用上述初始化数组和长度创建了一个MTRand_int32类型的对象irand，用于生成32位整数的随机数
// this is an example of initializing by an array
// you may use MTRand(seed) with any 32bit integer
// as a seed for a simpler initialization
  MTRand drand; // double in [0, 1) generator, already init  创建了一个默认初始化的MTRand类型对象drand，用于生成位于[0, 1)范围内的双精度浮点数的随机数。

// generate the same numbers as in the original C test program
  ros::init(argc, argv, "global_rrt_frontier_detector"); //调用ros::init函数初始化ROS节点
  ros::NodeHandle nh;//创建一个ros::NodeHandle对象nh，用于与ROS系统进行通信
  
  // fetching all parameters
  float eta,init_map_x,init_map_y,range;//声明了一些变量，包括eta、init_map_x、init_map_y、range、map_topic和base_frame_topic，用于存储参数值
  std::string map_topic,base_frame_topic;
  
  std::string ns;
  ns=ros::this_node::getName();//使用ros::this_node::getName()获取当前节点的命名空间，并将其存储在变量ns中。

  ros::param::param<float>(ns+"/eta", eta, 0.5);//使用ros::param::param函数从参数服务器中获取eta和map_topic的值，并将其分别存储在对应的变量中
  ros::param::param<std::string>(ns+"/map_topic", map_topic, "/robot_1/map"); 
//---------------------------------------------------------------
ros::Subscriber sub= nh.subscribe(map_topic, 100 ,mapCallBack);	//创建了一个名为sub的ros::Subscriber对象，订阅了map_topic指定的话题，并指定回调函数为mapCallBack
ros::Subscriber rviz_sub= nh.subscribe("/clicked_point", 100 ,rvizCallBack);//创建了一个名为rviz_sub的ros::Subscriber对象，订阅了"/clicked_point"话题，并指定回调函数为rvizCallBack

ros::Publisher targetspub = nh.advertise<geometry_msgs::PointStamped>("/detected_points", 10);//创建了一个名为targetspub的ros::Publisher对象，用于发布geometry_msgs::PointStamped类型的消息到"/detected_points"话题
ros::Publisher pub = nh.advertise<visualization_msgs::Marker>(ns+"_shapes", 10);//创建了一个名为pub的ros::Publisher对象，用于发布visualization_msgs::Marker类型的消息到ns+"_shapes"话题

ros::Rate rate(100); //创建了一个名为rate的ros::Rate对象，用于控制程序循环的频率为100Hz
 
 
// wait until map is received, when a map is received, mapData.header.seq will not be < 1  
while (mapData.header.seq<1 or mapData.data.size()<1)  {  ros::spinOnce();  ros::Duration(0.1).sleep();}//在接收到地图数据后，通过检查mapData.header.seq和mapData.data.size()的值，确保地图数据已接收完整



//visualizations  points and lines..   设置可视化消息对象points和line的各项属性，包括frame_id、类型、操作、尺寸、颜色等
points.header.frame_id=mapData.header.frame_id;
line.header.frame_id=mapData.header.frame_id;
points.header.stamp=ros::Time(0);
line.header.stamp=ros::Time(0);
	
points.ns=line.ns = "markers";
points.id = 0;
line.id =1;


points.type = points.POINTS;
line.type=line.LINE_LIST;

//Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
points.action =points.ADD;//设置points和line的动作类型为ADD，表示向可视化环境添加新的元素
line.action = line.ADD;
points.pose.orientation.w =1.0;//置points和line的姿态方向的w分量为1.0，表示没有旋转
line.pose.orientation.w = 1.0;
line.scale.x =  0.03;//线段的宽度
line.scale.y= 0.03;
points.scale.x=0.3; //点的大小
points.scale.y=0.3; 

line.color.r =9.0/255.0;//线的颜色，为蓝色
line.color.g= 91.0/255.0;
line.color.b =236.0/255.0;
points.color.r = 255.0/255.0;//points的颜色为红色
points.color.g = 0.0/255.0;
points.color.b = 0.0/255.0;
points.color.a=1.0;//设置points和line的颜色的透明度为1.0，表示完全不透明
line.color.a = 1.0;
points.lifetime = ros::Duration();//将points和line的生命周期设置为空持续时间，表示它们在可视化环境中一直存在
line.lifetime = ros::Duration();

geometry_msgs::Point p;  //创建一个geometry_msgs::Point类型的变量p


while(points.points.size()<5) //当points.points.size()小于5时，执行以下操作：
{
ros::spinOnce();//在循环中，通过调用ros::spinOnce()处理接收到的消息

pub.publish(points) ;//发布points消息
}




std::vector<float> temp1;//将points.points[0]的x和y坐标分量添加到temp1中
temp1.push_back(points.points[0].x);
temp1.push_back(points.points[0].y);
	
std::vector<float> temp2; //将points.points[2]的x和y坐标分量添加到temp2中
temp2.push_back(points.points[2].x);
temp2.push_back(points.points[0].y);


init_map_x=Norm(temp1,temp2);//使用Norm函数计算temp1和temp2之间的距离，将结果赋值给init_map_x
temp1.clear();		temp2.clear();//清空temp1和temp2

temp1.push_back(points.points[0].x);//将points.points[0]的x和y坐标分量添加到temp1中
temp1.push_back(points.points[0].y);

temp2.push_back(points.points[0].x);//将points.points[0]的x和points.points[2]的y坐标分量添加到temp2中
temp2.push_back(points.points[2].y);

init_map_y=Norm(temp1,temp2);//使用Norm函数计算temp1和temp2之间的距离，将结果赋值给init_map_y
temp1.clear();		temp2.clear();//清空temp1和temp2

Xstartx=(points.points[0].x+points.points[2].x)*.5;//计算X坐标的起始位置，将points.points[0]和points.points[2]的x坐标取平均值赋值给Xstartx
Xstarty=(points.points[0].y+points.points[2].y)*.5;//计算Y坐标的起始位置，将points.points[0]和points.points[2]的y坐标取平均值赋值给Xstarty





geometry_msgs::Point trans;//将trans赋值为points.points[4]，即点的坐标
trans=points.points[4];
std::vector< std::vector<float>  > V; //创建一个名为V的二维浮点型向量，用于存储点的坐标
std::vector<float> xnew; //创建一个名为xnew的浮点型向量，并将trans.x和trans.y添加到其中
xnew.push_back( trans.x);xnew.push_back( trans.y);  
V.push_back(xnew);//将xnew添加到V中

points.points.clear();//清空points.points并发布
pub.publish(points) ;







std::vector<float> frontiers;//创建一个名为frontiers的浮点型向量，用于存储前沿数据
int i=0;
float xr,yr;//创建两个浮点型变量xr和yr，用于存储随机生成的点的坐标
std::vector<float> x_rand,x_nearest,x_new;//创建三个浮点型向量x_rand、x_nearest和x_new，用于存储随机生成的点、最近点和新点的坐标


// Main loop
while (ros::ok()){


// Sample free
x_rand.clear();//清空x_rand向量
xr=(drand()*init_map_x)-(init_map_x*0.5)+Xstartx;//使用随机数生成器drand生成一个介于-init_map_x/2和init_map_x/2之间的随机数，并将其存储在xr中
yr=(drand()*init_map_y)-(init_map_y*0.5)+Xstarty;//使用随机数生成器drand生成一个介于-init_map_y/2和init_map_y/2之间的随机数，并将其存储在yr中


x_rand.push_back( xr ); x_rand.push_back( yr );//将xr和yr添加到x_rand向量中，表示随机生成的点的坐标


// Nearest
x_nearest=Nearest(V,x_rand);//使用Nearest函数找到V中与x_rand最近的点的坐标，并将结果赋值给x_nearest

// Steer

x_new=Steer(x_nearest,x_rand,eta);//使用Steer函数在x_nearest和x_rand之间生成新的点的坐标，并将结果赋值给x_new


// ObstacleFree    1:free     -1:unkown (frontier region)      0:obstacle
char   checking=ObstacleFree(x_nearest,x_new,mapData);//使用ObstacleFree函数检查从x_nearest到x_new的路径上是否存在障碍物。返回值checking表示检查结果

	  if (checking==-1){//如果checking等于-1，表示路径上存在未知区域（frontier region），执行以下操作：
          	exploration_goal.header.stamp=ros::Time(0);//设置exploration_goal的时间戳为当前时间，帧ID为mapData的帧ID
          	exploration_goal.header.frame_id=mapData.header.frame_id;//设置exploration_goal的坐标为x_new的x和y分量，z坐标为0.0
          	exploration_goal.point.x=x_new[0];//将x_new的坐标添加到points的点列表中。
          	exploration_goal.point.y=x_new[1];
          	exploration_goal.point.z=0.0;
          	p.x=x_new[0]; //
			p.y=x_new[1]; 
			p.z=0.0;
          	points.points.push_back(p);
          	pub.publish(points) ;  //发布points消息
          	targetspub.publish(exploration_goal);//发布exploration_goal消息
		  	points.points.clear();//清空points.points向量
        	
        	}
	  	
	  
	  else if (checking==1){//如果checking等于1，表示路径上是自由区域（free），执行以下操作：
	 	V.push_back(x_new);//将x_new添加到V中，表示发现一个新的自由区域
	 	
	 	p.x=x_new[0]; 
		p.y=x_new[1]; 
		p.z=0.0;
	 	line.points.push_back(p);//将x_new和x_nearest的坐标添加到line的点列表中，用于可视化线段
	 	p.x=x_nearest[0]; 
		p.y=x_nearest[1]; 
		p.z=0.0;
	 	line.points.push_back(p);

	        }



pub.publish(line);  //发布line消息，用于可视化线段


   

ros::spinOnce();//调用ros::spinOnce()处理接收到的消息
rate.sleep();//通过rate.sleep()控制循环的频率
  }return 0;}//返回0表示程序运行成功结束
