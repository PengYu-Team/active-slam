#coding=utf-8

import math
import os
import pickle
import sys
import rospy
import gym
import matplotlib
import numpy as np
import torch
from PIL import Image
from torch.nn import functional as F
from torchvision import transforms

if sys.platform == 'darwin':
    matplotlib.use("tkagg")
else:
    matplotlib.use('Agg')
import matplotlib.pyplot as plt
from nav_msgs.msg import OccupancyGrid

mapData = OccupancyGrid()
fullmap = OccupancyGrid()
def mapCallBack(data):
    global mapData
    mapData = data
def fullMap(data):  # 多机器人情况下，更新全局地图
    global fullmap
    fullmap = data

class Exploration_Env:


    def __init__(self, args, rank):
        if args.visualize:
            plt.ion()
        if args.print_images or args.visualize:
            self.figure, self.ax = plt.subplots(1, 2, figsize=(6*16/9, 6),
                                                facecolor="whitesmoke",
                                                num="Thread {}".format(rank))       #绘制一个包含1行2列的子图网格

        self.args = args
        self.num_actions = 3        #表示智能体可以采取的动作数量
        self.dt = 10                #每个时间步长为10秒。

        self.rank = rank            #该参数通常用于多线程或分布式训练中，表示当前线程/进程的ID。


#        config_env.defrost()                    #配置仿真环境的动作空间。对detectron2的配置文件进行解冻，以允许对其进行修改。
#        config_env.SIMULATOR.ACTION_SPACE_CONFIG = \
#                "CustomActionSpaceConfiguration"        #将动作空间配置为自定义的配置文件
#        config_env.freeze()                        #再次冻结配置文件，以防止对其进行进一步修改。


        self.action_space = gym.spaces.Discrete(self.num_actions)   #设置动作空间为离散的动作空间，动作数量为 self.num_actions。

        self.observation_space = gym.spaces.Box(0, 255,
                                                (3, args.frame_height,
                                                    args.frame_width),
                                                dtype='uint8')   #设置观测空间为像素值在 $[0, 255]$ 之间的三通道图像，大小为 (3, args.frame_height, args.frame_width)

#        self.mapper = self.build_mapper()   #创建一个将场景坐标映射到图像坐标的映射器。

        self.episode_no = 0  #初始化当前的回合数为 0。

        self.res = transforms.Compose([transforms.ToPILImage(),
                    transforms.Resize((args.frame_height, args.frame_width),
                                      interpolation = Image.NEAREST)])      #设置将场景图像转换为指定大小的 PIL 图像的转换器。
        self.scene_name = None  #初始化场景名称为空。
        self.maps_dict = {}     #创建一个字典，用于存储场景的地图信息。

#    def randomize_env(self):
#        self._env._episode_iterator._shuffle_iterator()  #将环境中的所有场景随机排序，以便在训练过程中不会有特定场景的偏差

    def save_trajectory_data(self):  #将模拟器中采集到的轨迹数据保存到本地文件
        if "replica" in self.scene_name:   #首先通过 self.scene_name 变量获取当前场景的名称，然后根据名称创建一个对应的文件夹。
            folder = self.args.save_trajectory_data + "/" + \
                        self.scene_name.split("/")[-3]+"/"
        else:
            folder = self.args.save_trajectory_data + "/" + \
                        self.scene_name.split("/")[-1].split(".")[0]+"/"
        if not os.path.exists(folder):
            os.makedirs(folder)
        filepath = folder+str(self.episode_no)+".txt"
        with open(filepath, "w+") as f:
            f.write(self.scene_name+"\n")
            for state in self.trajectory_states:
                f.write(str(state)+"\n")              #将当前轨迹的状态数据按顺序写入到以该轨迹序号命名的文件中
            f.flush()

   # def save_position(self):
      #  self.agent_state = self._env.sim.get_agent_state()
     #   self.trajectory_states.append([self.agent_state.position,
     #                                  self.agent_state.rotation])


    def reset(self):
        args = self.args
        self.episode_no += 1
        self.timestep = 0
        self._previous_action = None
        self.trajectory_states = []

 #       if args.randomize_env_every > 0:      #检查是否需要随机化环境。使用 np.mod() 求余数来判断是否需要随机化。self.episode_no 表示当前的 episode 数量。
 #           if np.mod(self.episode_no, args.randomize_env_every) == 0:
 #               self.randomize_env()

        # Get Ground Truth Map  获取可探索地图并初始化先前探索的区域。在这个环境中，地图的可探索区域是动态的
        self.explorable_map = None
#        global_costmap_topic = rospy.get_param(
#            '~global_costmap_topic', '/move_base_node/global_costmap/costmap')
        rospy.Subscriber('/robot_1/move_base_node/global_costmap/costmap', OccupancyGrid, fullMap)
        rospy.Subscriber('robot_1/map', OccupancyGrid, mapCallBack)
        while self.explorable_map is None:
            full_map_size = args.map_size_cm//args.map_resolution
            self.explorable_map = args.explorable_map
        self.prev_explored_area = 0.



        # Initialize variables
#        self.visited = np.zeros(fullmap.shape)  #记录哪些地方已经被访问过，初始化为全零矩阵
#        self.visited_vis = np.zeros(self.map.shape)  #用于可视化的访问地图，也是一个全零矩阵
#        self.visited_gt = np.zeros(self.map.shape)  #记录哪些地方已经被访问过的地图
#        self.collison_map = np.zeros(self.map.shape)  #记录哪些地方存在障碍物，初始化为全零矩阵
        self.col_width = 1  #障碍物的宽度，初始化为1

        # Set info
        self.info = {
            'time': self.timestep,
            'sensor_pose': [0., 0., 0.],
            'pose_err': [0., 0., 0.],
        }

        # area, ratio = self.get_global_reward()  # area和ratio是根据机器人当前位置周围的地图信息计算出的全局探索奖励。
        # self.info['exp_reward'] = area
        # self.info['exp_ratio'] = ratio
    #    self.save_position()

        return self.info

    def step(self, action):  #输入参数为 action，返回值为 obs（观测数据）、rew（奖励）、done（是否完成）、info（其他信息）

        args = self.args
        self.timestep += 1

        # Action remapping
        if action == 2: # Forward   对 action 进行了重新映射，将 2（前进）转为 1
            action = 1
        elif action == 1: # Right  将 1（右转）转为 3
            action = 3
        elif action == 0: # Left  将 0（左转）转为 2
            action = 2

        self.map_size_cm = args.map_size_cm    #对地图大小进行了设置
#        self.mapper.reset_map(self.map_size_cm)
        self.curr_loc = [self.map_size_cm/100.0/2.0,
                         self.map_size_cm/100.0/2.0, 0.]  #将机器人当前位置设置为地图中心，同时将角度设置为0。
        self.curr_loc_gt = self.curr_loc  #机器人在全局坐标系中的起始位置
        self.last_loc_gt = self.curr_loc_gt  #机器人上一步在全局坐标系中的位置信息
        self.last_loc = self.curr_loc  #机器人上一步在地图坐标系中的位置信息
#        self.last_sim_location = self.get_sim_location()
        self.last_loc = np.copy(self.curr_loc)      #复制
        self.last_loc_gt = np.copy(self.curr_loc_gt)
        self._previous_action = action


        obs = mapData
        rew = self.get_reward(obs)
        done = self.get_done(obs)
        info = self.get_info(obs)
        # Preprocess observations当机器人执行一个新的动作时，它首先通过habitat环境获取观察结果(obs)，其中包含RGB图像和深度图像。
        #rgb = obs['rgb'].astype(np.uint8)  #将RGB图像从Habitat环境中获取，并将其转换为无符号8位整数数组（np.uint8）
        #self.obs = rgb # For visualization
        #if self.args.frame_width != self.args.env_frame_width:  #如果帧的宽度与环境帧的宽度不同，则使用给定的缩放函数对RGB图像进行缩放
        #    rgb = np.asarray(self.res(rgb))


        # Update collision map机器人在执行前进或后退动作时，检查是否与障碍物发生碰撞，并在发生碰撞时将机器人的位置标记在碰撞地图上。
        if action == 1:  #如果动作是前进或后退（即 action == 1），则获取当前位置和上一个位置，并计算它们之间的欧几里得距离。
            x1, y1, t1 = self.last_loc
            x2, y2, t2 = self.curr_loc
            if abs(x1 - x2)< 0.05 and abs(y1 - y2) < 0.05:  #判断机器人当前的位置与上一个位置之间的距离是否小于设定的阈值，如果小于，则将机器人的碰撞宽度加2，最大不超过9。
                self.col_width += 2
                self.col_width = min(self.col_width, 9)
            else:          #如果距离大于阈值，则将碰撞宽度重置为1
                self.col_width = 1


        # Set info 将一些信息记录在类属性self.info中
        self.info['time'] = self.timestep


        if self.timestep%args.num_local_steps==0: #如果当前的时间步数（self.timestep）可以被args.num_local_steps整除，就执行下面的代码。这通常用于控制训练中的一些特殊操作，例如每隔一定步数计算全局奖励或者保存训练数据等。
            area, ratio = self.get_global_reward()  #area和ratio是根据机器人当前位置周围的地图信息计算出的全局探索奖励。
            self.info['exp_reward'] = area
            self.info['exp_ratio'] = ratio
        else:
            self.info['exp_reward'] = None
            self.info['exp_ratio'] = None

      #  self.save_position()

        if self.info['time'] >= args.max_episode_length:  #如果当前的时间步time超过了最大允许时间步max_episode_length，则标记此次episode已结束
            done = True
            if self.args.save_trajectory_data != "0":  #如果指定了保存轨迹数据save_trajectory_data，则将其保存。
                self.save_trajectory_data()
        else:
            done = False

        return rew, done, self.info #返回当前的状态state、奖励rew、是否结束done以及保存的信息self.info

    def get_reward_range(self):
        # This function is not used, Habitat-RLEnv requires this function
        return (0., 1.0)

    def get_reward(self, observations):
        # This function is not used, Habitat-RLEnv requires this function
        return 0.

    def get_global_reward(self, mapData1):  #计算全局奖励，返回当前探索面积和探索率。探索率是指已探索的区域与可探索区域的比率。
        width = mapData1.info.width
        height = mapData1.info.height
        data = mapData1.data
        occupied_count = 0
        free_count = 0
        count = 0
        for i in range(height):
            for j in range(width):
                value = data[i * width + j]  # 将二维数组的索引(i, j)转换为一维数组的索引
                if value > 0:  # 假设大于0的值表示占据
                    occupied_count += 1
                elif value < 0:  # 假设等于0的值表示空闲
                    free_count += 1
                count = occupied_count + free_count
        m_reward = count
        # self.explored_map = mapData
        # curr_explored = fullmap #计算当前探索地图(explored_map)和可探索地图(explorable_map)的交集，得到已探索区域(curr_explored)。
        # curr_explored_area = self.calculate_explored_area(fullmap)  #计算当前已探索区域的面积
        #
        # reward_scale = self.explorable_map  #self.explorable_map.sum()可探索地图区域的总面积
        # m_reward = (curr_explored_area - self.prev_explored_area)*1.  #计算本次探索行为获得的奖励(m_reward)，即使用当前探索的面积-先前探索的面积 计算差异，得到本次探索的区域
        # m_ratio = m_reward/reward_scale  #计算本次探索行为获得的奖励相对于可探索区域总面积的比例
        # m_reward = m_reward * 25./10000. # converting to m^2  #将m_reward的单位从像素数转换为平方米。
        # self.prev_explored_area = curr_explored_area

        m_reward *= 0.02 # Reward Scaling将m_reward按比例进行缩放

        return m_reward

    def get_done(self, observations):
        # This function is not used, Habitat-RLEnv requires this function
        return False

    def get_info(self, observations):
        # This function is not used, Habitat-RLEnv requires this function
        info = {}
        return info

    def seed(self, seed):  #设置随机数生成器的种子，以便使实验可重现
        self.rng = np.random.RandomState(seed)

    def get_spaces(self):  #返回环境的观察空间和动作空间
        return self.observation_space, self.action_space

    def calculate_explored_area(self, curr_explored):
        width = curr_explored.info.width
        height = curr_explored.info.height
        resolution = curr_explored.info.resolution

        # 获取地图数据
        map_data = curr_explored.data

        explored_cells = 0
        for i in range(width * height):
            # 判断单元格是否被标记为"占据"，值为100
            if map_data[i] == 1:
                explored_cells += 1

        # 计算面积
        explored_area = explored_cells * resolution * resolution

        return explored_area