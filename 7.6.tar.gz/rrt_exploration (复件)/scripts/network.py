#!/usr/bin/env python2
#coding=utf-8


import time
from collections import deque

import os

os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np
import torch
import torch.nn as nn

import gym
import logging
from arguments import get_args
#from env import make_vec_envs
from storage import GlobalRolloutStorage
from model import RL_Policy

import algo

import matplotlib

matplotlib.use("tkagg")
import matplotlib.pyplot as plt

import rospy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped
from functions import Robot
from scripts.exploration_env import Exploration_Env

from actionlib import SimpleActionClient
from move_base_msgs.msg import MoveBaseAction
from actionlib_msgs.msg import GoalStatus
MoveBaseClient = SimpleActionClient('move_base', MoveBaseAction)


#plt.ion()



class GMapPose:
    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
gmap_pose = GMapPose()

class MPose:
    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
mpose = MPose()



args = get_args()   #从命令行中解析参数

np.random.seed(args.seed)  #设置随机种子以确保在不同运行时得到相同的随机结果。分别设置Numpy和PyTorch的随机数生成器的种子
torch.manual_seed(args.seed)

if args.cuda:
    torch.cuda.manual_seed(args.seed)  #设置PyTorch中的随机数生成器的种子（seed），以保证在每次运行时得到的结果都是一致的。当 args.cuda 为 True 时，使用 torch.cuda.manual_seed() 方法设置生成器的种子，以确保在使用GPU时也能够得到一致的结果。当 args.cuda 为 False 时，使用 torch.manual_seed() 方法设置生成器的种子。

mapData = OccupancyGrid()
fullmap = OccupancyGrid()
mapData1 = OccupancyGrid()
fullmap1 = OccupancyGrid()

def get_local_map_boundaries(agent_loc, local_sizes, full_sizes):      #获得局部地图的边界，还需要传入全局地图的大小（full_sizes）.首先获取agent在全局地图中的位置，然后根据局部地图的大小和agent的位置计算出局部地图的边界
    loc_r, loc_c = agent_loc
    local_w, local_h = local_sizes
    full_w, full_h = full_sizes

    if args.global_downscaling > 1:        #如果全局地图进行了缩放（>1）,局部地图的大小将被缩小，以保证局部地图不会超出全局地图的范围
        gx1, gy1 = loc_r - local_w // 2, loc_c - local_h // 2
        gx2, gy2 = gx1 + local_w, gy1 + local_h
        if gx1 < 0:
            gx1, gx2 = 0, local_w
        if gx2 > full_w:
            gx1, gx2 = full_w - local_w, full_w

        if gy1 < 0:
            gy1, gy2 = 0, local_h
        if gy2 > full_h:
            gy1, gy2 = full_h - local_h, full_h
    else:
        gx1, gx2, gy1, gy2 = 0, full_w, 0, full_h

    return [gx1, gx2, gy1, gy2]          #返回局部地图的边界

def mapCallBack(data):
    global mapData, mapData1
    mapData = data
    mapData1 = data
def fullMap(data):  # 多机器人情况下，更新全局地图
    global fullmap, fullmap1
    fullmap = data
    fullmap1 = data


def gmap_pose_callback(pose_msg):
    # 从接收到的消息中提取gmap_pose
    global gmap_pose
    gmap_pose.x = pose_msg.pose.position.x
    gmap_pose.y = pose_msg.pose.position.y
    gmap_pose.theta = pose_msg.pose.orientation.z
#    gmap_pose = torch.tensor([gmap_pose.x, gmap_pose.y, gmap_pose.theta])
def mpose_callback(mpose_msg):
    # 从接收到的消息中提取mpose
    global mpose
    mpose.x = mpose_msg.pose.position.x
    mpose.y = mpose_msg.pose.position.y
    mpose.theta = mpose_msg.pose.orientation.z
 #   mpose = torch.tensor([mpose.x, mpose.y, mpose.theta])




def node():
    rospy.init_node('network', anonymous=False)
    # Setup Logging设置训练日志和结果存储目录
    m1_dir = "{}/m1/{}/".format(args.dump_location, args.exp_name)
    log_dir = "{}/models/{}/".format(args.dump_location, args.exp_name) #存储训练日志
    dump_dir = "{}/dump/{}/".format(args.dump_location, args.exp_name)  #存储结果

    if not os.path.exists(m1_dir):
        os.makedirs(m1_dir)

    if not os.path.exists(log_dir):
        os.makedirs(log_dir)           #如果这两个目录不存在，则使用 os.makedirs() 创建它们

    if not os.path.exists("{}/images/".format(dump_dir)):
        os.makedirs("{}/images/".format(dump_dir))

    logging.basicConfig(            #配置了一个文件日志记录器，用于将训练日志记录到指定的日志文件中
        filename=log_dir + 'train.log',
        level=logging.INFO)
    print("Dumping at {}".format(log_dir))     #打印了存储目录和命令行参数，并将它们写入到训练日志中
    print(args)
    logging.info(args)

    # Logging and loss variables
    num_scenes = args.num_processes
    num_episodes = int(args.num_episodes)
    device = args.device = torch.device("cuda:0" if args.cuda else "cpu")
    policy_loss = 0              #policy_loss初始化为0

    best_cost = 100000           #最好的代价值，初始为很大的数
    costs = deque(maxlen=1000)   #这三个变量都是使用双端队列（deque）定义的，用于记录最近的代价值，长度限制为1000


    g_masks = torch.ones(num_scenes).float().to(device)  #这两个变量使用torch张量定义，g_masks初始化为全1，l_masks初始化为全0。

    best_g_reward = -np.inf   #表示最佳的全局奖励值，初始化为负无穷

    rateHz = rospy.get_param('~rate', 100)  # 循环频率
#    rospy.init_node("map_subscriber")
    map_topic = rospy.get_param('~map_topic', '/map')
    delay_after_assignement = rospy.get_param('~delay_after_assignement', 0.5)  # 分配后延迟时间
    rateHz = rospy.get_param('~rate', 100)
#    rospy.init_node('gmap_pose_subscriber')
    gmap_pose = rospy.Subscriber('robot_1/gmap_pose_topic', PoseStamped, gmap_pose_callback)
#    rospy.init_node('mpose_subscriber')
    mpose = rospy.Subscriber('robot_1/mpose_topic', PoseStamped, mpose_callback)
    rospy.Subscriber('robot_1/map', OccupancyGrid, mapCallBack)
    rospy.Subscriber('/robot_1/move_base_node/global_costmap/costmap', OccupancyGrid, fullMap)
    rospy.Subscriber('robot_1/map', OccupancyGrid, mapCallBack)
    namespace = rospy.get_param('~namespace', '')  # 命名空间
    robot = Robot('robot_1')  # 创建单个机器人对象



    if args.eval:
        traj_lengths = args.max_episode_length  #轨迹长度，初始化为全局最大步数除以每个局部步数
        explored_area_log = np.zeros((num_scenes, num_episodes, traj_lengths))  #用于记录探索率，初始化为0
        explored_ratio_log = np.zeros((num_scenes, num_episodes, traj_lengths)) #用于记录探索率，初始化为0

    g_episode_rewards = deque(maxlen=1000) #使用双端队列（deque）记录最近1000个全局奖励值


    g_value_losses = deque(maxlen=1000) #全局价值损失
    g_action_losses = deque(maxlen=1000) #全局动作损失
    g_dist_entropies = deque(maxlen=1000) #全局分布熵值

    per_step_g_rewards = deque(maxlen=1000) #每步的全局奖励

    g_process_rewards = np.zeros((num_scenes)) #全局过程奖励，初始化为0


    # Initialize map variables
    ### Full map consists of 4 channels containing the following:
    ### 1. Obstacle Map
    ### 2. Exploread Area
    ### 3. Current Agent Location
    ### 4. Past Agent Locations

    torch.set_grad_enabled(False)  #关闭梯度计算，在一些只需要进行前向传播的计算中，可以通过调用该函数来提高计算效率。

    # Calculating full and local map sizes
    map_size = args.map_size_cm // args.map_resolution   #地图大小和分辨率
    # full_w, full_h = map_size , map_size
    # local_w, local_h = int(full_w / args.global_downscaling), \
    #                    int(full_h / args.global_downscaling)
    full_w, full_h = map_size, map_size
    local_w, local_h = int(map_size / args.global_downscaling * 2), \
                       int(map_size / args.global_downscaling * 2)

    # Initializing full and local map
    fullmap = torch.zeros(num_scenes, 4, full_w, full_h).float().to(device)
    mapData = torch.zeros(num_scenes, 4, local_w, local_h).float().to(device)

    # Initial full and local pose
    gmap_pose = torch.zeros(num_scenes, 3).float().to(device)
    mpose = torch.zeros(num_scenes, 3).float().to(device)

    # Origin of local map局部地图的原点
    origins = np.zeros((num_scenes, 3))

    # Local Map Boundaries局部地图边界（数组）
    lmb = np.zeros((num_scenes, 4)).astype(int)

    ### Planner pose inputs has 7 dimensions
    ### 1-3 store continuous global agent location
    ### 4-7 store local map boundaries
    planner_pose_inputs = np.zeros((num_scenes, 7))


    env = Exploration_Env(args, 1 )
    infos = env.reset()


    def init_map_and_pose():
        gmap_pose.fill_(0.)
        gmap_pose.fill_(0.)   #将全局地图和全局姿态张量填充为零  和初始化一样吗
        gmap_pose[:, :2] = args.map_size_cm / 100.0 / 2.0   #将全局姿态的前两个值设置为地图的中心坐标（第三个值应该是朝向）

        locs = gmap_pose.cpu().numpy()   #全局姿态。将full_pose转换为numpy数组并赋值给locs变量。locs是一个形状为(num_scenes, 3)的数组，其中每一行包含一个场景中机器人的行坐标，列坐标和朝向。
        planner_pose_inputs[:, :3] = locs
        for e in range(num_scenes):         #对于每个场景
            r, c = locs[e, 1], locs[e, 0]   #使用全局姿态张量中的位置信息来确定在地图上的位置。从全局姿态张量 locs 中获取第 e 个场景的行和列坐标信息
            loc_r, loc_c = [int(r * 100.0 / args.map_resolution),
                            int(c * 100.0 / args.map_resolution)]     #将行和列坐标乘以一个缩放系数 100.0 / args.map_resolution 并取整，从而得到在地图中的行和列索引

            fullmap[e, 2:, loc_r - 1:loc_r + 2, loc_c - 1:loc_c + 2] = 1.0

            lmb[e] = get_local_map_boundaries((loc_r, loc_c),  #确定局部地图的边界，并将边界信息存储在lmb数组中
                                              (local_w, local_h),
                                              (full_w, full_h))

            planner_pose_inputs[e, 3:] = lmb[e]
            origins[e] = [lmb[e][2] * args.map_resolution / 100.0,          #origins是局部地图的原点，对每个场景，它是一个长度为 3 的一维数组，包含局部地图左下角的坐标值，单位是米
                          lmb[e][0] * args.map_resolution / 100.0, 0.]

        for e in range(num_scenes):
            mapData[e] = fullmap[e, :, lmb[e, 0]:lmb[e, 1], lmb[e, 2]:lmb[e, 3]] #使用边界信息从全局地图中提取出每个场景的局部地图
            mpose[e] = gmap_pose[e] - \
                            torch.from_numpy(origins[e]).to(device).float()  #用 torch.from_numpy 将 origins 数组转换为 PyTorch 张量，并将其移动到与 full_pose 张量相同的设备上，以便进行张量运算。将原点从完整的位姿中减去，以得到在局部地图坐标系中的局部位姿。local_pose 是一个大小为 (num_scenes, 3) 的张量，其中 num_scenes 表示场景的数量。对于每个场景，它的前两个元素表示在地图坐标系中机器人的位置，第三个元素表示机器人的朝向。

    init_map_and_pose()




    # Global policy observation space  定义全局观测空间
    g_observation_space = gym.spaces.Box(0, 1,          #使用gym.spaces.Box()来创建一个有界的连续数值空间，包含8个通道，每个通道的尺寸为local_w * local_h，值的范围在0到1之间
                                         (8,
                                          local_w,
                                          local_h), dtype='uint8')

    # Global policy action space   全局动作空间
    g_action_space = gym.spaces.Box(low=0.0, high=1.0,  #动作空间是一个由两个浮点数组成的向量，取值范围在0到1之间。具体来说，这意味着每个时间步，全局策略将输出一个2维向量，表示机器人在地图中应该执行的运动指令。
                                    shape=(2,), dtype=np.float32)


    # Local and Global policy recurrent layer sizes 局部和全局策略的循环神经网络隐藏层大小
    g_hidden_size = args.global_hidden_size

    # Global policy
    g_policy = RL_Policy(g_observation_space.shape, g_action_space,    #g_policy 是一个全局策略模型，由输入和输出空间大小，基本参数以及其他参数初始化。
                         base_kwargs={'recurrent': args.use_recurrent_global,
                                      'hidden_size': g_hidden_size,
                                      'downscaling': args.global_downscaling     #输入的下采样倍率
                                      }).to(device)             #该模型会被送入 g_agent 对象，用于执行 PPO 算法
    g_agent = algo.PPO(g_policy, args.clip_param, args.ppo_epoch,     #使用PPO算法初始化一个全局策略代理。g_policy：代理使用的策略模型。args.clip_param：PPO算法中用于剪切比率的参数。args.ppo_epoch：PPO算法中执行的训练时期数量
                       args.num_mini_batch, args.value_loss_coef,     #args.num_mini_batch：每个训练时期中用于训练的小批次数量。args.value_loss_coef：PPO算法中值函数损失的系数
                       args.entropy_coef, lr=args.global_lr, eps=args.eps, #args.entropy_coef：PPO算法中熵损失的系数。lr：PPO算法的学习率。eps：PPO算法的RMSprop优化器中的小数项，以提高数值稳定性
                       max_grad_norm=args.max_grad_norm)   #max_grad_norm：PPO算法中梯度的最大范数，以防止梯度爆炸


    # Storage
    g_rollouts = GlobalRolloutStorage(args.num_global_steps,        #g_rollouts 是一个全局经验存储，它用于在PPO算法中存储全局策略的回合数据。
                                      num_scenes, g_observation_space.shape,
                                      g_action_space, g_policy.rec_state_size,
                                      1).to(device)          #这里的1是指回合的数量，这里只存储一个回合。


    # Loading model  加载训练好的模型，以及设置模型的训练或评估模式

    if args.load_global != "0":   #如果 args.load_global 不为 "0"，则加载已训练好的全局模型参数，并将其加载到 g_policy 中。
        print("Loading global {}".format(args.load_global))
        state_dict = torch.load(args.load_global,
                                map_location=lambda storage, loc: storage)
        g_policy.load_state_dict(state_dict)

    if not args.train_global:    #如果 args.train_global 为 False，则将 g_policy 设置为评估模式，否则为训练模式。
        g_policy.eval()


    # Compute Global policy input
    locs = mpose.cpu().numpy()          #将机器人局部位姿信息（在局部地图中的位置和方向）转换为numpy数组，将张量中的值取出来作为数组中的元素，以便后续操作和计算。第160行定义的locs是全局位姿信息
    global_input = torch.zeros(num_scenes, 8, local_w, local_h)   #创建张量并初始化为0.稍后将使用局部地图信息和完整地图信息进行更新。local_w和local_h分别是局部地图的宽度和高度
    global_orientation = torch.zeros(num_scenes, 1).long()       #机器人的全局朝向

    for e in range(num_scenes):
        r, c = locs[e, 1], locs[e, 0]         #分别是行和列坐标
        loc_r, loc_c = [int(r * 100.0 / args.map_resolution),
                        int(c * 100.0 / args.map_resolution)]

        mapData[e, 2:, loc_r - 1:loc_r + 2, loc_c - 1:loc_c + 2] = 1.  #将local_map张量中第e个环境的第3至最后两个通道，在第loc_r - 1至loc_r + 2行，第loc_c - 1至loc_c + 2列的区域赋值为1。也就是说，该操作会在地图上绘制一个3x3大小的方框。
        global_orientation[e] = int((locs[e, 2] + 180.0) / 5.)  #将局部 SLAM 预测的机器人朝向转换为全局地图中的离散方向。locs 是一个包含所有机器人位置和方向的矩阵，其中 locs[:, 2] 表示机器人的方向。180.0 表示将机器人朝向的角度转换为范围在 -180 度到 180 度之间的角度，然后将它除以 5 取整，以获得离散的方向值。这个值将存储在一个名为 global_orientation 的张量中，以便在训练全局策略时使用。

#    global_input[:, 0:4, :, :] = mapData.detach()   #前四个通道存储局部地图信息。使用 detach() 方法将局部地图从计算图中分离，以便在使用 global_input 作为模型的输入时不会反向传播到局部地图。
#    global_input[:, 4:, :, :] = nn.MaxPool2d(args.global_downscaling)(fullmap)   #后四个通道是整个地图的下采样（downsampling）版本（通过对 full_map 应用最大池化实现）
    global_input[:, 0:4, :, :] = mapData.detach()
    global_input[:, 4:, :, :] = fullmap



    g_rollouts.obs[0].copy_(global_input)             #将global_input和global_orientation的值复制到g_rollouts.obs[0]和g_rollouts.extras[0]中。
    g_rollouts.extras[0].copy_(global_orientation)

    # Run Global Policy (global_goals = Long-Term Goal)          g_action_log_prob：采样动作的对数概率。g_rec_states：策略网络的输出状态（RNN状态），作为下一个时间步骤的初始状态。
    g_value, g_action, g_action_log_prob, g_rec_states = g_policy.act(g_rollouts.obs[0],g_rollouts.rec_states[0], g_rollouts.masks[0], extras=g_rollouts.extras[0], deterministic=False)                                     #执行g_policy
              #global_input
                   #缓存中第一个时间步骤的状态，作为策略网络的初始状态（RNN状态）
                       #缓存中第一个时间步骤的状态，作为策略网络的掩码，指示该时间步骤是否是当前轨迹的结束状态。
                #缓存中第一个时间步骤的附加信息，作为策略网络的额外输入。
                        #指示采样动作是否是确定性的。当deterministic=True时，采用确定性策略输出一个动作，否则采用随机策略输出一个动作。


    cpu_actions = nn.Sigmoid()(g_action).cpu().numpy()   #将g_action（即全局策略网络的输出）通过一个Sigmoid激活函数处理后，将结果移动到CPU上，并将其转换为Numpy数组
    global_goals = [[int(action[0] * local_w * 0.01), int(action[1] * local_h * 0.01)]
                    for action in cpu_actions]  #根据g_policy产生的动作，计算出对应的全局目标位置。具体来说，这段代码首先将连续动作中的每个元素（action）乘以局部特征图的宽度和高度（local_w和local_h），得到一个以像素为单位的相对位移量。然后将该相对位移量转换为一个离散目标（global_goals），其包含两个整数元素，分别表示在全局地图上的水平和垂直偏移量。
    gmap_pose = mpose + torch.from_numpy(origins).to(device).float()
    locs = gmap_pose.cpu().numpy()
    r, c = locs[0][0], locs[0][1]
    loc_r, loc_c = [int(r / args.map_resolution),
                    int(c / args.map_resolution)]
    goals = [action[0] * 10, action[1] * 10] # local_w * 0.01
    robot.sendGoal(goals)  # 将该机器人分配到对应的前沿点
    rospy.loginfo("  assigned to  " + str(goals))

#    robot.client.wait_for_result()
#    if robot.client.get_state() == GoalStatus.SUCCEEDED:
#        rospy.loginfo("Already reached the goal!")
#    else:
#        rospy.loginfo("Failed to reach the goal!")
    # -------------------------------------------------------------------------


    start = time.time()

    total_num_steps = -1  #初始化计数器total_num_steps为-1，以便在第一次更新计数器时得到计数器值为0。
    g_reward1 = 0
    global_reward = 0  #初始化全局奖励g_reward为0，以便在执行每个场景的动作后计算奖励。

    torch.set_grad_enabled(False)  #禁用PyTorch的自动求导机制（torch.set_grad_enabled(False)），以便在执行动作时不需要计算梯度。

    # 记录程序开始时间
    start_time = time.time()
    g_value_losses_list = []
    g_action_losses_list = []
    g_dist_entropies_list = []
    g_episode_rewards_list = []
    # 设置定时器的间隔时间（单位：秒）
    interval = 3600  # 30分钟
    fig_global_loss = None
    fig_global_rewards = None

    for ep_num in range(num_episodes):      #迭代次数上限
        for step in range(args.max_episode_length):   #最大迭代长度
            total_num_steps += 1

            g_step = step  // args.num_global_steps #当前训练的全局步数
            eval_g_step = step // args.num_global_steps + 1 #当前评估的全局步数

            # ------------------------------------------------------------------
            # Global Policy
            if step < args.num_global_steps:   #意味着它是在处理每个局部步骤的循环的最后一次迭代中使用的
                # For every global step, update the full and local maps  在机器人周围的环境地图上运行卷积神经网络来估计机器人的当前位置，并根据当前位置来更新局部地图和全局地图
                for e in range(num_scenes):  # 迭代每个场景（即机器人所在的不同环境），将局部地图拼接为全局地图，并更新机器人的全局位姿、局部地图边界。对于每个场景，首先将局部地图的信息复制到全局地图的相应位置。然后更新当前机器人的位置，并根据机器人的位置计算新的局部地图的边界。接着将新的局部地图的边界信息和原点信息存储到输入规划器的数据结构中。最后，从全局地图中提取当前场景的局部地图和机器人的位姿，减去原点信息得到局部地图中机器人的位姿。

                    rospy.Subscriber('robot_1/mpose_topic', PoseStamped, mpose_callback)
                    rospy.Subscriber('robot_1/gmap_pose_topic', PoseStamped, gmap_pose_callback)
                    rospy.Subscriber('/robot_1/move_base_node/global_costmap/costmap', OccupancyGrid, fullMap)
                    rospy.Subscriber('robot_1/map', OccupancyGrid, mapCallBack)

                    fullmap[e, :, lmb[e, 0]:lmb[e, 1], lmb[e, 2]:lmb[e, 3]] = \
                        mapData[e]                                                     #lmb：局部地图的边界
                    gmap_pose[e] = mpose[e] + \
                                   torch.from_numpy(origins[e]).to(device).float()

                    locs = gmap_pose[e].cpu().numpy()
                    r, c = locs[1], locs[0]
                    loc_r, loc_c = [int(r * 100.0 / args.map_resolution),
                                    int(c * 100.0 / args.map_resolution)]

                    lmb[e] = get_local_map_boundaries((loc_r, loc_c),  #根据机器人的当前位置获取局部地图的边界
                                                      (local_w, local_h),
                                                      (full_w, full_h))

                    origins[e] = [lmb[e][2] * args.map_resolution / 100.0,       #origins[e]表示局部地图左上角的位置（以米为单位），即局部地图的原点在全局地图上的位置。
                                  lmb[e][0] * args.map_resolution / 100.0, 0.]   #根据lmb计算出机器人在局部地图中的原点位置

                    mapData[e] = fullmap[e, :,
                                   lmb[e, 0]:lmb[e, 1], lmb[e, 2]:lmb[e, 3]]  #从全局地图中提取当前场景的局部地图和机器人的位姿。刚开始的时候是把局部地图的信息复制给了全局地图了
                    mpose[e] = gmap_pose[e] - \
                                    torch.from_numpy(origins[e]).to(device).float()   #全局位姿减去原点信息 得到局部地图中机器人的位姿

                locs = mpose.cpu().numpy()
                for e in range(num_scenes):                        # 计算机器人的全局朝向，并更新全局输入
                    global_orientation[e] = int((locs[e, 2] + 180.0) / 5.)     #首先从locs数组中获取每个场景的yaw角（即绕z轴旋转的角度），并加上180度以确保其为正值。然后将其除以5并将结果转换为整数
                global_input[:, 0:4, :, :] = mapData                         # 将local_map的前四个通道（即占据、激光距离、遮挡和当前位置）分配给global_input张量的前四个通道。
                global_input[:, 4:, :, :] = fullmap           #将full_map张量的后三个通道（即高度、地图边界和当前位置的全局方向）分配给global_input张量的后三个通道。对于每个通道，使用最大池化对全局地图进行下采样。


                # Get exploration reward and metrics
                g_reward1 = env.get_global_reward(mapData1)
                global_reward = global_reward + g_reward1
                g_reward = torch.from_numpy(np.asarray(global_reward)).float().to(device)  # 从 infos 中获取每个环境 env_idx 的 exp_reward，并将它们转化为PyTorch张量 g_reward



                if args.eval:                       #如果是在评估模式下
                    g_reward = g_reward * 50.0  # Convert reward to area in m2       将 g_reward 值乘以 50.0，将奖励值转换为以平方米为单位的面积

#                g_process_rewards += g_reward.cpu().numpy()               #将每个场景的 g_reward 累加到 g_process_rewards 中，以计算累积奖励
#                g_total_rewards = g_process_rewards * \
#                                  (1 - g_masks.cpu().numpy())             #将所有场景的 g_process_rewards 加到 g_total_rewards 中，其中 g_masks 表示是否已经完成任务。若已完成该场景，那么g_process_rewards*0
#                g_process_rewards *= g_masks.cpu().numpy()
#                per_step_g_rewards.append(np.mean(g_reward.cpu().numpy()))   #将每个场景的平均 g_reward 添加到 per_step_g_rewards 列表中

                # if np.sum(g_total_rewards) != 0:
                #     for tr in g_total_rewards:
                #         g_episode_rewards.append(tr) if tr != 0 else None  #将当前的全局奖励（g_total_rewards）添加到一个列表 g_episode_rewards 中，但是如果当前的全局奖励为 0，则不添加。这样做的目的可能是在统计全局奖励时，过滤掉一些无效的奖励值。

                if args.eval:                                             #评估模式下，记录探索比率
                    exp_ratio = torch.from_numpy(np.asarray(
                        [infos[env_idx]['exp_ratio'] for env_idx
                         in range(num_scenes)])
                    ).float()

                    for e in range(num_scenes):
                        explored_area_log[e, ep_num, eval_g_step - 1] = \
                            explored_area_log[e, ep_num, eval_g_step - 2] + \
                            g_reward[e].cpu().numpy()                             #存储每个场景的累计探索面积。ep_num 是当前评估的第几个 episode，eval_g_step 是当前 episode 进行的步数。
                        explored_ratio_log[e, ep_num, eval_g_step - 1] = \
                            explored_ratio_log[e, ep_num, eval_g_step - 2] + \
                            exp_ratio[e].cpu().numpy()                            #存储每个场景的累计探索比率。最终得到的 explored_area_log 和 explored_ratio_log 可以用于评估模型的性能。

                # Add samples to global policy storage
                g_rollouts.insert(                                        #将全局导航的一步转移数据保存到g_rollouts对象中
                    global_input, g_rec_states,
                    g_action, g_action_log_prob, g_value,
                    g_reward, g_masks, global_orientation
                )

                # Sample long-term goal from global policy      执行global policy
                g_value, g_action, g_action_log_prob, g_rec_states = g_policy.act(g_rollouts.obs[g_step + 1], g_rollouts.rec_states[g_step + 1], g_rollouts.masks[g_step + 1], extras=g_rollouts.extras[g_step + 1], deterministic=False)
                cpu_actions = nn.Sigmoid()(g_action).cpu().numpy()        #将动作映射到[0,1]之间
                global_goals = [[int(action[0] * local_w),                #根据当前局部地图的宽高计算出全局坐标系中的全局目标
                                 int(action[1] * local_h)]
                                for action in cpu_actions]

                gmap_pose = mpose + torch.from_numpy(origins).to(device).float()
                locs = gmap_pose.cpu().numpy()
                r, c = locs[0][0], locs[0][1]
                loc_r, loc_c = [int(r / args.map_resolution),
                                int(c / args.map_resolution)]

                goals = [action[0] * 10, action[1] * 10]  # local_w * 0.01
                robot.sendGoal(goals)  # 将该机器人分配到对应的前沿点
                rospy.loginfo("  assigned to  " + str(goals))

                robot.client.wait_for_result()
                if robot.client.get_state() == GoalStatus.SUCCEEDED:
                    rospy.loginfo("Already reached the goal!")
                else:
                    rospy.loginfo("Failed to reach the goal!")
                g_reward = 0
                g_masks = torch.ones(num_scenes).float().to(device)       #将g_reward重置为0，g_masks重置为全1
            # ------------------------------------------------------------------

            ### TRAINING
            torch.set_grad_enabled(True)  #开启梯度计算功能，以便在反向传播期间执行自动微分。在深度学习模型训练中，通常需要在训练过程中开启梯度计算，以便使用反向传播算法更新模型参数。

            # ------------------------------------------------------------------
            # Train Global Policy
            if g_step % args.num_global_steps == args.num_global_steps - 1:
                       #如果满足条件，则表示完成了一个完整的训练周期，需要对全局控制策略模型进行更新。
                if args.train_global:
                    g_next_value = g_policy.get_value(                           #计算当前状态的估计价值。参数都是获取了列表最后一个值。“g_rollouts”表示当前的回放缓冲区
                        g_rollouts.obs[-1],                                      #[-1]是Python中的一种索引方式，表示获取列表中的最后一个元素
                        g_rollouts.rec_states[-1],
                        g_rollouts.masks[-1],
                        extras=g_rollouts.extras[-1]
                     ).detach()

                    g_rollouts.compute_returns(g_next_value, args.use_gae,    #计算回合数据的折扣收益值。其中，g_next_value表示全局模型在最后一个状态的价值估计，args.use_gae表示是否使用广义优势估计（Generalized Advantage Estimation，GAE），args.gamma表示折扣因子，args.tau是GAE中的超参数。
                                                   args.gamma, args.tau)
                    g_value_loss, g_action_loss, g_dist_entropy = \
                        g_agent.update(g_rollouts)                                 #对全局控制策略模型进行更新。“g_dist_entropy”策略熵
                    g_value_losses.append(g_value_loss)
                    g_action_losses.append(g_action_loss)
                    g_dist_entropies.append(g_dist_entropy)             #将计算出的全局模型的价值、动作和熵损失分别添加到对应的列表g_value_losses、g_action_losses和g_dist_entropies中，以便后续的分析和可视化。
                g_rollouts.after_update()                                          #重置用于收集数据的回合数据
            # ------------------------------------------------------------------
            if args.train_global:
                torch.save(g_policy.state_dict(),
                       os.path.join(m1_dir, "model1.global"))


            if args.train_global:
                # g_value_losses_list.append(np.mean(g_value_losses))
                # g_action_losses_list.append(np.mean(g_action_losses))
                # g_dist_entropies_list.append(np.mean(g_dist_entropies))
                # fig_global_loss = plt.figure(3)
                # plt.plot(g_value_losses_list, label='g_value', color='red')
                # plt.plot(g_action_losses_list, label='g_action', color='blue')
                # plt.plot(g_dist_entropies_list, label='g_dist', color='green')
                # ax = plt.gca()
                # if not ax.get_legend():
                #     ax.legend(handles=[
                #         plt.Line2D([], [], color='red', label='g_value'),
                #         plt.Line2D([], [], color='blue', label='g_action'),
                #         plt.Line2D([], [], color='green', label='g_dist')
                #     ])
                # plt.title('Global Loss')
                # plt.xlabel('Step')
                # plt.ylabel('GLOBAL Loss')
                # plt.show(block=False)
                # plt.pause(0.001)

                fig_global_rewards = plt.figure(4)
                plt.plot(step, g_reward1, linewidth=2.0)
                plt.title('Global Rewards')
                plt.xlabel('Step')
                plt.ylabel('Global Rewards')
                plt.show()
                plt.pause(0.001)


            elapsed_time = time.time() - start_time
            if elapsed_time > interval:

                if args.train_global and plt.fignum_exists(3):
                # 保存 Global Loss 图片
                    if not os.path.exists('/home/y/rrt/src/rrt_exploration/scripts/pictures/global_loss'):
                        os.makedirs('/home/sysu/yyz/pictures/global_loss')
                    fig_global_loss.savefig("/home/y/rrt/src/rrt_exploration/scripts/pictures/global_loss/global_loss_{}.png".format(step))


 #                   fig_global_loss.savefig("/home/sysu/yyz/pictures/global_loss/global_loss_{}.png".format(step))
                if plt.fignum_exists(4):
                # 保存 Global Rewards 图片
                    fig_global_rewards.savefig("/home/y/rrt/src/rrt_exploration/scripts/pictures/global_rewards/global_rewards_{}.png".format(step))
                start_time = time.time()


                        # Finish Training
            torch.set_grad_enabled(False)
            # ------------------------------------------------------------------

            # ------------------------------------------------------------------
            # Logging        定期记录日志
            if total_num_steps % args.log_interval == 0:
                end = time.time()
                time_elapsed = time.gmtime(end - start)                    #计算训练时间，并使用time.gmtime()将其转换为时间格式（日/小时/分钟/秒）
                log = " ".join([
                    "Time: {0:0=2d}d".format(time_elapsed.tm_mday - 1),
                    "{},".format(time.strftime("%Hh %Mm %Ss", time_elapsed)),
                    "num timesteps {},".format(total_num_steps *
                                               num_scenes),
                    "FPS {},".format(int(total_num_steps * num_scenes \
                                         / (end - start)))
                ])                                                         #将格式化的时间和一些有关训练进度和性能的信息（例如总步数、每秒帧数和奖励值等）添加到日志中

                log += "\n\tRewards:"

                if len(g_episode_rewards) > 0:
                    log += " ".join([
                        " Global step mean/med rew:",
                        "{:.4f}/{:.4f},".format(
                            np.mean(per_step_g_rewards),
                            np.median(per_step_g_rewards)),
                        " Global eps mean/med/min/max eps rew:",
                        "{:.3f}/{:.3f}/{:.3f}/{:.3f},".format(
                            np.mean(g_episode_rewards),             #对全局的回报信息求均值
                            np.median(g_episode_rewards),           #中位数
                            np.min(g_episode_rewards),
                            np.max(g_episode_rewards))
                    ])

                log += "\n\tLosses:"

                if args.train_global and len(g_value_losses) > 0:     #如果启用了全局训练，则将全局价值损失、动作损失和熵损失添加到日志中。
                    log += " ".join([
                        " Global Loss value/action/dist:",
                        "{:.3f}/{:.3f}/{:.3f},".format(
                            np.mean(g_value_losses),
                            np.mean(g_action_losses),
                            np.mean(g_dist_entropies))
                    ])


                print(log)                        #将日志打印到标准输出流
                logging.info(log)                 #将日志写入日志文件中

            # ------------------------------------------------------------------

            # ------------------------------------------------------------------
            # Save best models
            if (total_num_steps * num_scenes) % args.save_interval < \
                    num_scenes:

                # Save Global Policy Model
                if len(g_episode_rewards) >= 100 and \
                        (np.mean(g_episode_rewards) >= best_g_reward) \
                        and not args.eval:
                    torch.save(g_policy.state_dict(),
                               os.path.join(log_dir, "model_best.global"))
                    best_g_reward = np.mean(g_episode_rewards)

            # Save periodic models       除保存最好的模型文件外，在每 100000 步定期保存所有模型saved/dump/exp1/args.save_periodic表示保存的间隔步数，total_num_steps 表示训练的总步数，num_scenes 表示场景数。
            if (total_num_steps * num_scenes) % args.save_periodic < \
                    num_scenes:                                           #（total_num_steps * num_scenes） 对 args.save_periodic 取余小于 num_scenes，则表示已经训练了 total_num_steps 步，同时又经过了一轮所有的场景，这时就需要保存模型。
                step = total_num_steps * num_scenes

                if args.train_global:
                    torch.save(g_policy.state_dict(),
                               os.path.join(dump_dir,
                                            "periodic_{}.global".format(step)))
            # ------------------------------------------------------------------

    # Print and save model performance numbers during evaluation  在进行评估时记录探索过程中探索区域和探索比例的日志，并输出最终的探索区域和探索比例。
    if args.eval:  #如果 args.eval 为真，表示当前是在进行评估，代码会打开两个日志文件 {dump_dir}/explored_area.txt 和 {dump_dir}/explored_ratio.txt，并将探索区域和探索比例记录在这两个文件中。
        fig, ax = plt.subplots()
        ax.set_xlabel('Episode Length')
        ax.set_ylabel('Explored Ratio')
        # 初始化空列表存储数据点
        x_data = []
        y_data = []

        logfile = open("{}/explored_area.txt".format(dump_dir), "w+")
        for e in range(num_scenes):
            for i in range(explored_area_log[e].shape[0]):
                logfile.write(str(explored_area_log[e, i]) + "\n")
                logfile.flush()

        logfile.close()

        logfile = open("{}/explored_ratio.txt".format(dump_dir), "w+")
        for e in range(num_scenes):
            for i in range(explored_ratio_log[e].shape[0]):
                logfile.write(str(explored_ratio_log[e, i]) + "\n")
                logfile.flush()

        logfile.close()

        log = "Final Exp Area: \n"                       #计算所有场景的探索区域和探索比例的平均值，并将其格式化为一个字符串 log
        for i in range(explored_area_log.shape[2]):   #第一个 for迭代了 explored_area_log 张量的第三个维度，即迭代了不同时间步骤
            log += "{:.5f}, ".format(
                np.mean(explored_area_log[:, :, i]))  #在每个时间步骤上，计算每个场景的探索区域的平均值

        log += "\nFinal Exp Ratio: \n"
        for i in range(explored_ratio_log.shape[2]):  #第二个 for迭代了 explored_ratio_log 张量的第三个维度，即迭代了不同时间步骤
            log += "{:.5f}, ".format(
                np.mean(explored_ratio_log[:, :, i]))   #在每个时间步骤上，计算每个场景的探索比例的平均值
            # 计算当前 episode 的探索比例
            explored_ratio = np.mean(explored_ratio_log[:, :, i])

        print(log)
        logging.info(log)
    rospy.spin()

if __name__ == '__main__':
    try:
        node()
    except rospy.ROSInterruptException:
        pass
