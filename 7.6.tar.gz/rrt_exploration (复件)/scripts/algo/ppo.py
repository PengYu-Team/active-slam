#coding=utf-8
# The following code is largely borrowed from:
# https://github.com/ikostrikov/pytorch-a2c-ppo-acktr-gail/blob/master/a2c_ppo_acktr/algo/ppo.py

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


class PPO():

    def __init__(
        self,
        actor_critic,
        clip_param,
        ppo_epoch,
        num_mini_batch,
        value_loss_coef,
        entropy_coef,
        lr=None,
        eps=None,
        max_grad_norm=None,
        use_clipped_value_loss=True):

        self.actor_critic = actor_critic

        self.clip_param = clip_param
        self.ppo_epoch = ppo_epoch
        self.num_mini_batch = num_mini_batch

        self.value_loss_coef = value_loss_coef
        self.entropy_coef = entropy_coef

        self.max_grad_norm = max_grad_norm
        self.use_clipped_value_loss = use_clipped_value_loss

        self.optimizer = optim.Adam(filter(lambda p: p.requires_grad,
            actor_critic.parameters()), lr=lr, eps=eps)

    def update(self, rollouts):
        advantages = rollouts.returns[:-1] - rollouts.value_preds[:-1] #计算出所有轨迹的优势函数（advantages），这个值用来衡量每个时间步的状态-动作对相对于平均水平的优越性。
        advantages = (advantages - advantages.mean()) / (
                advantages.std() + 1e-5)   #将这些优势函数进行标准化，以使其均值为0，方差为1。

        value_loss_epoch = 0
        action_loss_epoch = 0
        dist_entropy_epoch = 0

        for e in range(self.ppo_epoch):  #执行ppo_epoch次更新迭代。每次迭代更新使用一个数据生成器（data_generator）从经验回放缓冲区（rollouts）中提取一定数量（num_mini_batch）的样本数据进行训练。

            if self.actor_critic.is_recurrent: #如果使用的是基于循环神经网络（RNN）的策略网络，则使用经验回放缓冲区中的recurrent_generator函数生成数据
                data_generator = rollouts.recurrent_generator(
                        advantages, self.num_mini_batch)
            else:
                data_generator = rollouts.feed_forward_generator(
                        advantages, self.num_mini_batch) #否则，使用feed_forward_generator函数生成数据。

            for sample in data_generator: #

                value_preds = sample['value_preds']
                returns = sample['returns']
                adv_targ = sample['adv_targ']

                # Reshape to do in a single forward pass for all steps
                values, action_log_probs, dist_entropy, _ = \
                        self.actor_critic.evaluate_actions(
                            sample['obs'], sample['rec_states'],
                            sample['masks'], sample['actions'],
                            extras=sample['extras']
                        ) #生成器产生的每个样本都包含观测数据（obs）、RNN状态（rec_states）、掩码（masks）、动作（actions）、价值估计（value_preds）、回报（returns）和优势估计（adv_targ）等信息。

                ratio = torch.exp(action_log_probs -
                                    sample['old_action_log_probs']) #根据小批量数据中的旧的动作对数值，计算出对应于当前策略的动作对数值
                surr1 = ratio * adv_targ
                surr2 = torch.clamp(ratio, 1.0 - self.clip_param,
                        1.0 + self.clip_param) * adv_targ           #计算出比率（ratio）和相应的优势函数估计值（surr1和surr2）
                action_loss = -torch.min(surr1, surr2).mean()  #使用上述计算结果来计算出策略损失函数

                if self.use_clipped_value_loss:        #计算出价值损失函数
                    value_pred_clipped = value_preds + \
                                        (values - value_preds).clamp(
                                            -self.clip_param, self.clip_param)
                    value_losses = (values - returns).pow(2)
                    value_losses_clipped = (value_pred_clipped
                                            - returns).pow(2)
                    value_loss = .5 * torch.max(value_losses,
                                                value_losses_clipped).mean()
                else:
                    value_loss = 0.5 * (returns - values).pow(2).mean()

                self.optimizer.zero_grad()
                (value_loss * self.value_loss_coef + action_loss -  #对于每个样本，首先从策略网络（actor_critic）中获取动作概率分布（action_log_probs）、价值估计（values）和策略熵（dist_entropy），然后计算该样本的损失函数，使用策略梯度优化算法对策略网络参数进行更新，以最大化预期回报。
                        dist_entropy * self.entropy_coef).backward()  #使用backward()函数计算出总体损失函数的梯度
                nn.utils.clip_grad_norm_(self.actor_critic.parameters(),
                                         self.max_grad_norm)  #使用梯度剪裁函数（clip_grad_norm_）来防止梯度爆炸
                self.optimizer.step()  #使用优化器（optimizer）来更新策略价值网络的参数

                value_loss_epoch += value_loss.item()  #跟踪每次更新迭代中的价值损失、策略损失和熵
                action_loss_epoch += action_loss.item()
                dist_entropy_epoch += dist_entropy.item()

        num_updates = self.ppo_epoch * self.num_mini_batch

        value_loss_epoch /= num_updates  #在更新迭代完成后返回它们的平均值，作为该迭代的性能指标，用于检测训练过程的收敛性
        action_loss_epoch /= num_updates
        dist_entropy_epoch /= num_updates

        return value_loss_epoch, action_loss_epoch, dist_entropy_epoch
