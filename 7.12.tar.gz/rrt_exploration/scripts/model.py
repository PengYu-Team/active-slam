#!/usr/bin/env python2
#coding=utf-8
import torch
import torch.nn as nn
import torchvision.models as models

from distributions import Categorical, DiagGaussian




class Flatten(nn.Module):
    def forward(self, x):
        return x.view(x.size(0), -1)


# https://github.com/ikostrikov/pytorch-a2c-ppo-acktr-gail/blob/master/a2c_ppo_acktr/model.py#L82
class NNBase(nn.Module):

    def __init__(self, recurrent, recurrent_input_size, hidden_size):

        super(NNBase, self).__init__()
        self._hidden_size = hidden_size
        self._recurrent = recurrent

        if recurrent:
            self.gru = nn.GRUCell(recurrent_input_size, hidden_size)
            nn.init.orthogonal_(self.gru.weight_ih.data)
            nn.init.orthogonal_(self.gru.weight_hh.data)
            self.gru.bias_ih.data.fill_(0)
            self.gru.bias_hh.data.fill_(0)

    @property
    def is_recurrent(self):
        return self._recurrent

    @property
    def rec_state_size(self):
        if self._recurrent:
            return self._hidden_size
        return 1

    @property
    def output_size(self):
        return self._hidden_size

    def _forward_gru(self, x, hxs, masks):
        if x.size(0) == hxs.size(0):
            x = hxs = self.gru(x, hxs * masks[:, None])
        else:
            # x is a (T, N, -1) tensor that has been flatten to (T * N, -1)
            N = hxs.size(0)
            T = int(x.size(0) / N)

            # unflatten
            x = x.view(T, N, x.size(1))

            # Same deal with masks
            masks = masks.view(T, N, 1)

            outputs = []
            for i in range(T):
                hx = hxs = self.gru(x[i], hxs * masks[i])
                outputs.append(hx)

            # x is a (T, N, -1) tensor
            x = torch.stack(outputs, dim=0)
            # flatten
            x = x.view(T * N, -1)

        return x, hxs



# Global Policy model code
class Global_Policy(NNBase):

    def __init__(self, input_shape, recurrent=False, hidden_size=512,
                 downscaling=1):               #input_shape：输入图像的形状，形式为（通道数，高度，宽度）。recurrent：指示是否使用循环神经网络，默认为False。downscaling：下采样因子，用于将输入图像缩小。默认为1，即不进行下采样。
        super(Global_Policy, self).__init__(recurrent, hidden_size,
                                            hidden_size)  #构造函数调用super()函数来调用父类Global_Policy的构造函数

        out_size = int(input_shape[1] / 16. * input_shape[2] / 16.)

        self.main = nn.Sequential(        #构造函数定义了一个main的序列，其中包括一些卷积层、ReLU激活函数和最大池化层，以及一个Flatten()层，用于将卷积层的输出展平成一个向量。这个序列将输入图像转换为一个特征向量。
            nn.MaxPool2d(2), #一个 2x2 的最大池化层
            nn.Conv2d(4, 32, 3, stride=1, padding=1), #一个输入通道为 8，输出通道为 32，卷积核大小为 3x3，步幅为 1，padding 为 1 的卷积层
            nn.ReLU(), #一个 ReLU 激活函数层；
            nn.MaxPool2d(2), #一个 2x2 的最大池化层；
            nn.Conv2d(32, 64, 3, stride=1, padding=1), #一个输入通道为 32，输出通道为 64，卷积核大小为 3x3，步幅为 1，padding 为 1 的卷积层；
            nn.ReLU(), #一个 ReLU 激活函数层；
            nn.MaxPool2d(2), #一个 2x2 的最大池化层；
            nn.Conv2d(64, 128, 3, stride=1, padding=1), #一个输入通道为 64，输出通道为 128，卷积核大小为 3x3，步幅为 1，padding 为 1 的卷积层；
            nn.ReLU(), #一个 ReLU 激活函数层；
            nn.MaxPool2d(2), #一个 2x2 的最大池化层；
            nn.Conv2d(128, 64, 3, stride=1, padding=1), #一个输入通道为 128，输出通道为 64，卷积核大小为 3x3，步幅为 1，padding 为 1 的卷积层；
            nn.ReLU(), #一个 ReLU 激活函数层；
            nn.Conv2d(64, 32, 3, stride=1, padding=1), #一个输入通道为 64，输出通道为 32，卷积核大小为 3x3，步幅为 1，padding 为 1 的卷积层；
            nn.ReLU(), #一个 ReLU 激活函数层；
            Flatten()      #最后一层不需要添加激活函数。将卷积层的输出展平成一个向量
        )

        self.linear1 = nn.Linear(out_size * 32 + 8, hidden_size)  #定义了三个线性层，分别为linear1，linear2和critic_linear。linear1将特征向量和机器人的方向编码（使用大小为8的嵌入层）连接起来，然后输出到linear2，最终输出到critic_linear，用于评估值函数。
        self.linear2 = nn.Linear(hidden_size, 256)
        self.critic_linear = nn.Linear(256, 1)
        self.orientation_emb = nn.Embedding(72, 8)  #定义了一个大小为(72, 8)的嵌入层，其中72是嵌入表的大小，表示机器人可能的方向数。嵌入表中的每个元素都代表了一个方向，从0到71编号。将编号0-71中的每个方向编码为一个大小为8的向量。
        self.train()

    def forward(self, inputs, rnn_hxs, masks, extras):  #前向传递函数。inputs表示机器人的观测数据；rnn_hxs表示RNN的初始隐状态；masks表示遮盖值，用于在RNN计算中控制信息流的强度；extras表示机器人的方向编码。
        x = self.main(inputs)  #使用self.main对inputs进行卷积操作
        orientation_emb = self.orientation_emb(extras).squeeze(1)  #使用self.orientation_emb对extras进行嵌入操作，将机器人的方向编码转换为一个向量，并使用squeeze函数将第二个维度的大小从1变为0。
        x = torch.cat((x, orientation_emb), 1)  #将卷积层的输出和方向编码向量连接到一起

        x = nn.ReLU()(self.linear1(x))  #输入到全连接层self.linear1中
        if self.is_recurrent:
            x, rnn_hxs = self._forward_gru(x, rnn_hxs, masks)  #如果self.is_recurrent为True，则调用self._forward_gru函数进行GRU计算。否则直接返回线性层的输出x

        x = nn.ReLU()(self.linear2(x))   #将输出传递到另一个全连接层self.linear2中，并通过ReLU函数激活

        return self.critic_linear(x).squeeze(-1), x, rnn_hxs   #将GRU的输出x输入到self.critic_linear线性层中，得到一个大小为1的输出，表示当前状态的价值估计。同时，也返回线性层的输出x和更新后的RNN隐状态rnn_hxs，这些信息可能在训练中被用于计算损失和优化模型。


# https://github.com/ikostrikov/pytorch-a2c-ppo-acktr-gail/blob/master/a2c_ppo_acktr/model.py#L15
class RL_Policy(nn.Module):

    def __init__(self, obs_shape, action_space, model_type=0,
                 base_kwargs=None):

        super(RL_Policy, self).__init__()
        if base_kwargs is None:    #检查 base_kwargs 是否为 None，如果是则将其赋值为空字典。这样做的目的是确保可以安全地在 base_kwargs 中添加或更新键值对，而不必担心该参数是否已被初始化。
            base_kwargs = {}

        if model_type == 0:         #目前只实现了model_type=0的全局策略网络（Global_Policy）
            self.network = Global_Policy(obs_shape, **base_kwargs)
        else:
            raise NotImplementedError

        if action_space.__class__.__name__ == "Discrete":
            num_outputs = action_space.n     #num_outputs则是输出动作的数量，对于离散动作空间就是动作的个数
            self.dist = Categorical(self.network.output_size, num_outputs)      #如果action_space的类型是离散的，就使用Categorical分布
        elif action_space.__class__.__name__ == "Box":
            num_outputs = action_space.shape[0]   #num_outputs对于连续动作空间就是每个动作的维度
            self.dist = DiagGaussian(self.network.output_size, num_outputs)     #如果action_space的类型是连续的，就使用DiagGaussian分布
        else:
            raise NotImplementedError

        self.model_type = model_type    #将model_type赋值给self.model_type

    @property
    def is_recurrent(self):
        return self.network.is_recurrent

    @property
    def rec_state_size(self):
        """Size of rnn_hx."""
        return self.network.rec_state_size

    def forward(self, inputs, rnn_hxs, masks, extras):
        if extras is None:
            return self.network(inputs, rnn_hxs, masks)
        else:
            return self.network(inputs, rnn_hxs, masks, extras)

    def act(self, inputs, rnn_hxs, masks, extras=None, deterministic=False):     #实现了一个Actor-Critic策略的act方法

        value, actor_features, rnn_hxs = self(inputs, rnn_hxs, masks, extras)     #调用当前策略网络的前向传递方法计算出状态值（value）、actor特征和RNN隐藏状态
        dist = self.dist(actor_features)  #利用actor特征调用Categorical或DiagGaussian对象的方法计算动作分布

        if deterministic:        # 使用分布采样出一个动作。如果deterministic为True，则会返回分布的众数（即最可能的动作）
            action = dist.mode()
        else:                        #否则将返回采样的动作
            action = dist.sample()

        action_log_probs = dist.log_probs(action)    #计算出所选动作的对数概率

        return value, action, action_log_probs, rnn_hxs      #将状态值、动作、动作对数概率和RNN隐藏状态作为输出返回

    def get_value(self, inputs, rnn_hxs, masks, extras=None):
        value, _, _ = self(inputs, rnn_hxs, masks, extras)
        return value

    def evaluate_actions(self, inputs, rnn_hxs, masks, action, extras=None):   #评估当前策略下，给定输入状态和动作的期望价值和策略分布的对数概率以及分布的熵

        value, actor_features, rnn_hxs = self(inputs, rnn_hxs, masks, extras)  #调用self函数获取值value、actor_features和rnn_hxs
        dist = self.dist(actor_features)      #使用actor_features通过self.dist(actor_features)来获取动作分布dist。

        action_log_probs = dist.log_probs(action)  #计算给定动作的对数概率
        dist_entropy = dist.entropy().mean()       #计算动作分布的熵

        return value, action_log_probs, dist_entropy, rnn_hxs





